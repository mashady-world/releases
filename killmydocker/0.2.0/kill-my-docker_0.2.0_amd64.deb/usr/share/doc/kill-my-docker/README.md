# killMyDocker

killMyDocker finds Docker projects you haven't used in a while and nags you to stop them, or stops them itself. That frees the RAM they're holding.

| Piece | What it is | Cost |
|---|---|---|
| `kmd` | Background watcher and CLI. Runs as a systemd user service. | ~3 MB RAM, ~0% CPU |
| `kmd-tray` | Top-bar icon with a menu listing every project. Runs as a systemd user service. | ~3 MB RAM |
| `kmd-gui` | GTK4 / libadwaita window. Runs only while it's open. | 0 when closed |

The tray and the window talk to `kmd` over a unix socket at `$XDG_RUNTIME_DIR/kmd.sock`.

## How it decides a project is idle

Containers are grouped by **compose project**. A container that isn't part of a compose project is treated as its own group. A project counts as idle when none of these things has happened for `idle_hours` (12 by default):

| Signal | Why |
|---|---|
| A file in the project folder changed, or there was git activity (commit, checkout, staging) | You're working on it. Generated folders such as `node_modules`, `vendor` and `storage`, plus `*.log` files, are skipped. |
| You started one of its containers yourself | Containers that start within 5 minutes after boot are restart-policy autostarts and don't count. |
| Its containers did real work: ≥ 5% CPU or ≥ 20 KB/s, measured over a window of at least 30 s | You're using it even if you aren't editing it. Schedulers, healthchecks and cron bursts stay far below this. |

## Memory: where your RAM really goes

The **Memory** tab (and `kmd mem`) splits RAM into **Apps · Docker · Desktop & background · System services · Kernel & shared**. It also shows file cache (which the kernel gives back on demand) and free memory.

- **Honest per-app numbers.** Each process counts its private memory: `RssAnon + RssShmem` from `/proc/<pid>/status`. That works for sandboxed browser tabs and root daemons too. Shared libraries are cache, so they aren't charged to every process that maps them, which is why these numbers are smaller than RSS-based tools.
- **The right owner.** GNOME often leaves a browser's tab processes inside `gnome-shell`'s own service, so other monitors list them as "System Processes". kmd groups processes by executable family (`/opt/brave.com/brave/*` → Brave) and matches them to installed apps. Docker containers are named by compose project. Programs started from a terminal (Claude Code, dev servers) are listed by name.
- **What no process owns** has its own rows: tmpfs and GPU buffers, kernel memory, and driver allocations.
- **History:** one sample per minute for 24 h, shown as a chart with a hover tooltip, plus each consumer's change over the last hour. History is saved to `~/.local/state/kmd/mem-history.jsonl` (~0.5 KB per sample, appended, trimmed to 24 h every hour), so it survives restarts, upgrades and reboots. Time the machine was off shows as a gap.
- **Alerts:** you get a notification when available RAM drops below `mem_alert_percent` (10%), or when one app grows by `mem_growth_alert_mb` (1500 MB) within an hour. Both are configurable in Settings.
- **Actions:** **Quit** an app (sends SIGTERM after you confirm) or **Stop** a Docker project, right from its row.

## Modes

- **alert** (default): you get a notification with **Stop now**, **Snooze** and **Details** buttons. If you close it without choosing, it comes back every `remind_minutes` until the project is stopped.
- **auto**: the project is stopped automatically (`docker stop`, so no data is lost) and you get a notification telling you.

## Install

**From a release (no Rust needed).** Download the latest `kill-my-docker_*_amd64.deb` from [Releases](../../releases/latest). Then:

```bash
sudo apt install ./kill-my-docker_*_amd64.deb
systemctl --user daemon-reload && systemctl --user start kmd kmd-tray   # or log out and back in
```

This installs to `/usr/bin` and enables the service and tray for every user's session. You need Ubuntu 24.04 or newer (GTK 4.12+ and libadwaita 1.5+), and your user must be in the `docker` group. Installing a newer `.deb` upgrades in place.

**From source:**

```bash
sudo apt install libgtk-4-dev libadwaita-1-dev     # only needed for the window
./install.sh
```

## Releases / CI

Every push to `main` runs [CI](.github/workflows/ci.yml). It tests and builds the code, packages a `.deb` (`packaging/build-deb.sh`), checks that the package installs, and publishes it as release `v<version>-build.<N>` (package version `<version>+build.<N>`). Pushing a tag such as `v0.3.0` publishes package version `0.3.0`. Bump the version in `Cargo.toml` when you tag, so the tagged package sorts above the earlier builds. Pull requests are built and tested only.

## Use

- **Window:** open "killMyDocker" from your apps menu, or run `kmd gui`.
- **Tray:** click the icon in the top bar.
- **CLI:**

  ```bash
  kmd status                  # projects, RAM, idle time, last activity
  kmd stop ctl                # stop a project now
  kmd start ctl               # start it again (uses `docker compose start`)
  kmd snooze ctl 24           # no alerts for 24h   (kmd unsnooze ctl)
  kmd ignore ctl              # never alert about it (kmd watch ctl)
  kmd mem                     # where your RAM goes (apps, Docker, desktop, system, kernel)
  kmd test-alert              # check that notifications + buttons work
  journalctl --user -u kmd -f
  ```

Settings live in `~/.config/kmd/config.toml`. You can edit them in the window's Settings tab or in the file. Either way, the daemon picks up changes without a restart. To exclude a container, give it the label `kmd.ignore=true`.

Uninstall: `./uninstall.sh`

## Layout

```
core/    shared lib: Docker socket client, activity scan, config, IPC protocol
daemon/  kmd       (watcher + CLI)
tray/    kmd-tray  (StatusNotifierItem via ksni)
gui/     kmd-gui   (GTK4 + libadwaita)
data/    systemd units, .desktop entry, icon
```
