// killMyDocker for GNOME Shell: top-bar numbers + popup (indicator.js). It also exports a tiny
// `dev.kmd.Extension` D-Bus object so the tray knows to step aside while the extension runs.
import Gio from 'gi://Gio';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {KmdIndicator} from './indicator.js';

const PRESENCE_IFACE = `
<node>
  <interface name="dev.kmd.Extension">
    <property name="Version" type="u" access="read"/>
  </interface>
</node>`;

export default class KmdExtension extends Extension {
    enable() {
        this._dbus = Gio.DBusExportedObject.wrapJSObject(PRESENCE_IFACE, {
            get Version() {
                return 1;
            },
        });
        this._dbus.export(Gio.DBus.session, '/dev/kmd/Extension');
        this._indicator = new KmdIndicator(this);
        Main.panel.addToStatusArea(this.uuid, this._indicator, 1, 'right');
    }

    disable() {
        this._dbus?.unexport();
        this._dbus = null;
        this._indicator?.destroy();
        this._indicator = null;
    }
}
