// Talks to the kmd daemon: one JSON request line over $XDG_RUNTIME_DIR/kmd.sock, one JSON reply
// line back (same protocol as core/src/ipc.rs).
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

Gio._promisify(Gio.SocketClient.prototype, 'connect_async');
Gio._promisify(Gio.OutputStream.prototype, 'write_all_async');
Gio._promisify(Gio.DataInputStream.prototype, 'read_line_async');

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function socketPath() {
    const dir = GLib.getenv('XDG_RUNTIME_DIR');
    return dir ? GLib.build_filenamev([dir, 'kmd.sock']) : `/tmp/kmd-${GLib.get_user_name()}.sock`;
}

/** Sends one request; resolves to the reply object, rejects with an Error on failure. */
export async function call(request, cancellable = null) {
    const client = new Gio.SocketClient({timeout: 90});
    let conn;
    try {
        conn = await client.connect_async(Gio.UnixSocketAddress.new(socketPath()), cancellable);
    } catch (e) {
        throw new Error('The kmd background service isn\'t running');
    }
    try {
        const line = encoder.encode(`${JSON.stringify(request)}\n`);
        await conn.get_output_stream().write_all_async(line, GLib.PRIORITY_DEFAULT, cancellable);
        const input = new Gio.DataInputStream({base_stream: conn.get_input_stream()});
        const [bytes] = await input.read_line_async(GLib.PRIORITY_DEFAULT, cancellable);
        if (!bytes)
            throw new Error('No reply from kmd');
        const reply = JSON.parse(decoder.decode(bytes));
        if (!reply.ok)
            throw new Error(reply.error || 'kmd returned an error');
        return reply;
    } finally {
        conn.close(null);
    }
}

/** "1.2 GiB" / "540 MiB", like kmd_core::util::fmt_bytes. */
export function fmtBytes(b) {
    const mib = (b || 0) / 1048576;
    return mib >= 1024 ? `${(mib / 1024).toFixed(1)} GiB` : `${Math.round(mib)} MiB`;
}

/** Compact form for the top bar: "1.2G" / "540M". */
export function fmtShort(b) {
    const mib = (b || 0) / 1048576;
    return mib >= 1024 ? `${(mib / 1024).toFixed(1)}G` : `${Math.round(mib)}M`;
}

/** "3m" / "2h 5m" / "1d 4h", like kmd_core::util::fmt_dur. */
export function fmtDur(s) {
    s = Math.max(0, Math.floor(s || 0));
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    if (d === 0 && h === 0)
        return `${m}m`;
    if (d === 0)
        return `${h}h ${m}m`;
    return `${d}d ${h}h`;
}

/**
 * Opens the kmd window on a page in its own systemd scope (so it never shares a cgroup with
 * gnome-shell), falling back to a plain spawn.
 */
export function openWindow(page = 'projects') {
    const argv = ['systemd-run', '--user', '--scope', '--collect', '--quiet', '--slice=app.slice', '--',
        'kmd-gui', `--page=${page}`];
    try {
        GLib.spawn_async(null, argv, null, GLib.SpawnFlags.SEARCH_PATH, null);
    } catch (e) {
        try {
            GLib.spawn_async(null, ['kmd-gui', `--page=${page}`], null, GLib.SpawnFlags.SEARCH_PATH, null);
        } catch (e2) {
            logError(e2, 'kmd: cannot open the window');
        }
    }
}

/** Runs a command and forgets about it (e.g. starting the kmd service). */
export function spawn(argv) {
    try {
        GLib.spawn_async(null, argv, null, GLib.SpawnFlags.SEARCH_PATH, null);
    } catch (e) {
        logError(e, `kmd: cannot run ${argv[0]}`);
    }
}
