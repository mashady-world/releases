// killMyDocker for GNOME Shell: top-bar numbers + popup (indicator.js) and Dynamic-Island
// notifications the daemon sends over D-Bus (island.js).
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {Island, exportIsland} from './island.js';
import {KmdIndicator} from './indicator.js';

export default class KmdExtension extends Extension {
    enable() {
        this._island = new Island(this.path);
        this._dbus = exportIsland(this._island);
        this._indicator = new KmdIndicator(this, this._island);
        Main.panel.addToStatusArea(this.uuid, this._indicator, 1, 'right');
    }

    disable() {
        this._dbus?.unexport();
        this._dbus = null;
        this._indicator?.destroy();
        this._indicator = null;
        this._island?.destroy();
        this._island = null;
    }
}
