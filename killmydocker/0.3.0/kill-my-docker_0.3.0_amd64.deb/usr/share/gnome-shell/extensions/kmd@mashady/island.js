// Dynamic-Island style notifications. A black pill grows out of the top-center of the panel,
// springs open into a card (icon, title, body, action buttons), then shrinks back into a small
// pill that stays until it is resolved (persistent alerts) or slides away (info).
//
// The daemon reaches it over D-Bus on GNOME Shell's own bus name:
//   org.gnome.Shell  /dev/kmd/Island  dev.kmd.Island.Notify(kind, title, body, actions, persistent) -> action
// Notify only returns when the user picked an action, closed it ("dismissed"), or it timed out
// ("timeout"), so the daemon can block on it exactly like `notify-send --wait`.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

export const ISLAND_IFACE = `
<node>
  <interface name="dev.kmd.Island">
    <method name="Notify">
      <arg type="s" direction="in" name="kind"/>
      <arg type="s" direction="in" name="title"/>
      <arg type="s" direction="in" name="body"/>
      <arg type="as" direction="in" name="actions"/>
      <arg type="b" direction="in" name="persistent"/>
      <arg type="s" direction="out" name="action"/>
    </method>
    <property name="Version" type="u" access="read"/>
  </interface>
</node>`;

/** Look per kind: accent color + icon. `icon` null means the bundled kmd icon. */
const KINDS = {
    idle: {accent: '#f5a623', icon: null},
    stopped: {accent: '#2ec27e', icon: 'emblem-ok-symbolic'},
    memory: {accent: '#ff453a', icon: 'speedometer-symbolic'},
    warning: {accent: '#ff9f0a', icon: 'dialog-warning-symbolic'},
    error: {accent: '#ff453a', icon: 'dialog-error-symbolic'},
    info: {accent: '#0a84ff', icon: 'dialog-information-symbolic'},
};

const COMPACT_W = 220;
const EXPANDED_W = 440;
const SEED_W = 64;
const OPEN_MS = 520;
const CLOSE_MS = 300;
/** How long the card stays open before collapsing (ms). Hover pauses it. */
const HOLD_MS = {persistent: 9000, transient: 6000};

const EASE_SPRING = Clutter.AnimationMode.EASE_OUT_BACK;
const EASE_SMOOTH = Clutter.AnimationMode.EASE_OUT_QUINT;

export class Island {
    constructor(extensionPath) {
        this._kmdIcon = Gio.FileIcon.new(Gio.File.new_for_path(`${extensionPath}/icons/kmd-symbolic.svg`));
        this._queue = []; // waiting items, oldest first
        this._current = null; // {kind,title,body,actions,persistent,resolve}
        this._state = 'hidden'; // hidden | compact | expanded
        this._holdId = 0;
        this._holdLeft = 0;
        this._holdStarted = 0;

        // Outer: the black rounded shape + shadow (never clipped, so the shadow stays round).
        // Inner: clips the content while the shape grows or shrinks around it.
        this._actor = new St.Widget({
            style_class: 'kmd-island',
            reactive: true,
            track_hover: true,
            opacity: 0,
            visible: false,
            layout_manager: new Clutter.BinLayout(),
        });
        this._inner = new St.Widget({
            clip_to_allocation: true,
            x_expand: true,
            y_expand: true,
            layout_manager: new Clutter.BinLayout(),
        });
        this._actor.add_child(this._inner);
        this._buildContent();

        this._actor.connect('notify::hover', () => this._onHover());
        this._actor.connect('button-release-event', () => {
            if (this._state === 'compact')
                this._expand();
            return Clutter.EVENT_STOP;
        });
        this._actor.connect('touch-event', (_a, ev) => {
            if (ev.type() === Clutter.EventType.TOUCH_END && this._state === 'compact')
                this._expand();
            return Clutter.EVENT_PROPAGATE;
        });

        // Above windows and popups. (GNOME 50 removed affectsInputRegion: reactive chrome gets input automatically.)
        Main.layoutManager.addTopChrome(this._actor, {trackFullscreen: true});
        this._monitorsId = Main.layoutManager.connect('monitors-changed', () => this._place(this._actor.width));
    }

    _buildContent() {
        // Compact row: icon + one-line title + queue badge.
        // Both layers have fixed widths and are centered, so while the pill grows the content is
        // revealed from the middle instead of re-wrapping on every frame.
        this._compact = new St.BoxLayout({
            style_class: 'kmd-island-compact',
            width: COMPACT_W,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.START,
        });
        this._compactIcon = new St.Icon({style_class: 'kmd-island-compact-icon', icon_size: 14});
        this._compactDot = new St.Widget({style_class: 'kmd-island-dot', y_align: Clutter.ActorAlign.CENTER});
        this._compactLabel = new St.Label({style_class: 'kmd-island-compact-label', x_expand: true, y_align: Clutter.ActorAlign.CENTER});
        this._compactLabel.clutter_text.ellipsize = 3; // Pango.EllipsizeMode.END
        this._badge = new St.Label({style_class: 'kmd-island-badge', y_align: Clutter.ActorAlign.CENTER, visible: false});
        this._compact.add_child(this._compactIcon);
        this._compact.add_child(this._compactLabel);
        this._compact.add_child(this._badge);
        this._compact.add_child(this._compactDot);

        // Expanded card.
        this._card = new St.BoxLayout({
            style_class: 'kmd-island-card',
            orientation: Clutter.Orientation.VERTICAL,
            width: EXPANDED_W,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.START,
        });
        const top = new St.BoxLayout({style_class: 'kmd-island-top'});
        this._bubble = new St.Bin({style_class: 'kmd-island-bubble', y_align: Clutter.ActorAlign.START});
        this._icon = new St.Icon({style_class: 'kmd-island-icon', icon_size: 22});
        this._bubble.set_child(this._icon);
        const texts = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true, style_class: 'kmd-island-texts'});
        this._eyebrow = new St.Label({style_class: 'kmd-island-eyebrow', text: 'killMyDocker'});
        this._title = new St.Label({style_class: 'kmd-island-title'});
        this._title.clutter_text.line_wrap = true;
        this._title.clutter_text.ellipsize = 0;
        this._body = new St.Label({style_class: 'kmd-island-body'});
        this._body.clutter_text.line_wrap = true;
        this._body.clutter_text.ellipsize = 0;
        texts.add_child(this._eyebrow);
        texts.add_child(this._title);
        texts.add_child(this._body);
        const close = new St.Button({
            style_class: 'kmd-island-close',
            child: new St.Icon({icon_name: 'window-close-symbolic', icon_size: 12}),
            y_align: Clutter.ActorAlign.START,
            accessible_name: 'Close',
        });
        close.connect('clicked', () => this._resolve('dismissed'));
        top.add_child(this._bubble);
        top.add_child(texts);
        top.add_child(close);

        this._actions = new St.BoxLayout({style_class: 'kmd-island-actions', x_expand: true});
        this._timer = new St.Widget({style_class: 'kmd-island-timer', x_expand: false});
        const timerTrack = new St.Widget({style_class: 'kmd-island-timer-track', x_expand: true, layout_manager: new Clutter.BinLayout()});
        timerTrack.add_child(this._timer);

        this._card.add_child(top);
        this._card.add_child(this._actions);
        this._card.add_child(timerTrack);
        this._timerTrack = timerTrack;

        this._inner.add_child(this._compact);
        this._inner.add_child(this._card);
    }

    /** D-Bus entry point (also used directly by the indicator for its own toasts). */
    notify({kind = 'info', title = '', body = '', actions = [], persistent = false}) {
        return new Promise(resolve => {
            const item = {kind, title, body, actions: parseActions(actions), persistent, resolve};
            if (!this._current) {
                this._current = item;
                this._show();
            } else {
                // Newest first: the current one goes back to the queue unless it was transient.
                this._queue.push(item);
                this._updateBadge();
                if (this._state === 'compact')
                    this._bounce();
            }
        });
    }

    // ------------------------------------------------------------ rendering

    _fill(item) {
        const look = KINDS[item.kind] ?? KINDS.info;
        const gicon = look.icon ? Gio.ThemedIcon.new(look.icon) : this._kmdIcon;
        this._icon.gicon = gicon;
        this._compactIcon.gicon = gicon;
        this._bubble.style = `background-color: ${hexA(look.accent, 0.22)}; box-shadow: 0 0 18px ${hexA(look.accent, 0.55)};`;
        this._icon.style = `color: ${look.accent};`;
        this._compactIcon.style = `color: ${look.accent};`;
        this._compactDot.style = `background-color: ${look.accent};`;
        this._timer.style = `background-color: ${hexA(look.accent, 0.9)};`;
        this._title.text = item.title;
        this._compactLabel.text = item.title;
        this._body.text = item.body;
        this._body.visible = !!item.body;

        this._actions.destroy_all_children();
        item.actions.forEach(({key, label}, i) => {
            const b = new St.Button({
                label,
                style_class: `kmd-island-button${i === 0 ? ' primary' : ''}`,
                x_expand: true,
                can_focus: true,
            });
            if (i === 0)
                b.style = `background-color: ${look.accent};`;
            b.connect('clicked', () => this._resolve(key));
            this._actions.add_child(b);
        });
        this._actions.visible = item.actions.length > 0;
        this._updateBadge();
    }

    _updateBadge() {
        const n = this._queue.length;
        this._badge.text = `+${n}`;
        this._badge.visible = n > 0;
    }

    _place(width) {
        const m = Main.layoutManager.primaryMonitor;
        if (!m)
            return;
        this._actor.set_position(Math.round(m.x + (m.width - width) / 2), m.y + 4);
    }

    _compactHeight() {
        return Math.max(26, Main.panel.height - 8);
    }

    _cardHeight() {
        this._card.opacity = 0;
        this._card.visible = true;
        const [, h] = this._card.get_preferred_height(EXPANDED_W);
        return Math.ceil(h);
    }

    // ------------------------------------------------------------ state machine

    _show() {
        this._fill(this._current);
        this._clearHold();
        const h0 = this._compactHeight();
        this._compact.height = h0;
        this._actor.remove_all_transitions();
        this._compact.opacity = 0;
        this._card.opacity = 0;
        this._actor.set_size(SEED_W, h0);
        this._actor.set_pivot_point(0.5, 0);
        this._actor.scale_x = 0.6;
        this._actor.scale_y = 0.6;
        this._place(SEED_W);
        this._actor.visible = true;
        this._actor.opacity = 0;
        this._actor.ease({
            opacity: 255,
            scale_x: 1,
            scale_y: 1,
            duration: 180,
            mode: EASE_SMOOTH,
            onComplete: () => this._expand(),
        });
    }

    _expand() {
        if (!this._current)
            return;
        this._state = 'expanded';
        const h = this._cardHeight();
        this._compact.ease({opacity: 0, duration: 120, mode: EASE_SMOOTH});
        this._easeBox(EXPANDED_W, h, OPEN_MS, EASE_SPRING);
        this._card.ease({opacity: 255, duration: 260, delay: 140, mode: EASE_SMOOTH});
        this._actor.add_style_class_name('expanded');
        this._startHold(this._current.persistent ? HOLD_MS.persistent : HOLD_MS.transient);
    }

    _collapse() {
        if (!this._current)
            return;
        this._clearHold();
        if (!this._current.persistent) {
            this._resolve('timeout');
            return;
        }
        this._state = 'compact';
        this._actor.remove_style_class_name('expanded');
        this._card.ease({opacity: 0, duration: 140, mode: EASE_SMOOTH});
        this._easeBox(COMPACT_W, this._compactHeight(), 420, EASE_SPRING);
        this._compact.ease({opacity: 255, duration: 220, delay: 160, mode: EASE_SMOOTH});
    }

    _bounce() {
        this._actor.ease({
            scale_x: 1.08, scale_y: 1.08, duration: 120, mode: EASE_SMOOTH,
            onComplete: () => this._actor.ease({scale_x: 1, scale_y: 1, duration: 380, mode: EASE_SPRING}),
        });
    }

    _easeBox(w, h, duration, mode) {
        const m = Main.layoutManager.primaryMonitor;
        const x = m ? Math.round(m.x + (m.width - w) / 2) : this._actor.x;
        this._actor.ease({width: w, height: h, x, duration, mode});
    }

    /** Finish the current item with `action`, then show the next one or close the island. */
    _resolve(action) {
        const item = this._current;
        if (!item)
            return;
        this._clearHold();
        this._current = null;
        item.resolve(action);
        const next = this._queue.shift();
        this._updateBadge();
        if (next) {
            this._current = next;
            // Morph straight into the next card.
            this._card.ease({
                opacity: 0, duration: 120, mode: EASE_SMOOTH,
                onComplete: () => {
                    this._fill(next);
                    this._expand();
                },
            });
            return;
        }
        this._hide();
    }

    _hide() {
        this._state = 'hidden';
        this._actor.remove_style_class_name('expanded');
        this._card.ease({opacity: 0, duration: 100, mode: EASE_SMOOTH});
        this._compact.ease({opacity: 0, duration: 100, mode: EASE_SMOOTH});
        const m = Main.layoutManager.primaryMonitor;
        this._actor.ease({
            width: SEED_W,
            height: this._compactHeight(),
            x: m ? Math.round(m.x + (m.width - SEED_W) / 2) : this._actor.x,
            duration: CLOSE_MS,
            mode: EASE_SMOOTH,
            onComplete: () => this._actor.ease({
                opacity: 0, scale_x: 0.6, scale_y: 0.6, duration: 160, mode: EASE_SMOOTH,
                onComplete: () => {
                    if (this._state === 'hidden')
                        this._actor.visible = false;
                },
            }),
        });
    }

    // ------------------------------------------------------------ auto-collapse timer

    _startHold(ms) {
        this._clearHold();
        this._holdLeft = ms;
        this._resumeHold();
    }

    _resumeHold() {
        if (this._holdId || this._holdLeft <= 0)
            return;
        this._holdStarted = GLib.get_monotonic_time();
        // Timer bar shrinks from the full width to zero over the remaining time.
        const full = EXPANDED_W - 32;
        this._timer.remove_all_transitions();
        this._timer.width = Math.round(full * this._holdLeft / this._holdTotal());
        this._timer.ease({width: 0, duration: this._holdLeft, mode: Clutter.AnimationMode.LINEAR});
        this._holdId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, this._holdLeft, () => {
            this._holdId = 0;
            this._holdLeft = 0;
            this._collapse();
            return GLib.SOURCE_REMOVE;
        });
    }

    _holdTotal() {
        return this._current?.persistent ? HOLD_MS.persistent : HOLD_MS.transient;
    }

    _pauseHold() {
        if (!this._holdId)
            return;
        GLib.source_remove(this._holdId);
        this._holdId = 0;
        this._holdLeft -= (GLib.get_monotonic_time() - this._holdStarted) / 1000;
        this._timer.remove_all_transitions();
    }

    _clearHold() {
        if (this._holdId)
            GLib.source_remove(this._holdId);
        this._holdId = 0;
        this._holdLeft = 0;
        this._timer.remove_all_transitions();
    }

    _onHover() {
        if (this._state !== 'expanded')
            return;
        if (this._actor.hover)
            this._pauseHold();
        else
            this._resumeHold();
    }

    destroy() {
        this._clearHold();
        for (const item of [this._current, ...this._queue])
            item?.resolve('dismissed');
        this._current = null;
        this._queue = [];
        if (this._monitorsId)
            Main.layoutManager.disconnect(this._monitorsId);
        Main.layoutManager.removeChrome(this._actor);
        this._actor.destroy();
    }
}

/** ["stop=Stop now", "snooze=Snooze"] -> [{key, label}] */
function parseActions(list) {
    return (list ?? []).map(a => {
        const i = a.indexOf('=');
        return i > 0 ? {key: a.slice(0, i), label: a.slice(i + 1)} : {key: a, label: a};
    }).slice(0, 3);
}

function hexA(hex, alpha) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

/** Exports the Island on GNOME Shell's session bus connection. Returns the exported object. */
export function exportIsland(island) {
    const impl = {
        get Version() {
            return 1;
        },
        NotifyAsync(params, invocation) {
            const [kind, title, body, actions, persistent] = params;
            island.notify({kind, title, body, actions, persistent})
                .then(action => invocation.return_value(new GLib.Variant('(s)', [action])))
                .catch(e => invocation.return_error_literal(Gio.DBusError, Gio.DBusError.FAILED, String(e)));
        },
    };
    const obj = Gio.DBusExportedObject.wrapJSObject(ISLAND_IFACE, impl);
    obj.export(Gio.DBus.session, '/dev/kmd/Island');
    return obj;
}
