// Top-bar indicator: kmd icon + live RAM / Docker numbers, and a popup with a RAM breakdown,
// the biggest consumers, every Docker project (Stop / Snooze / Start) and quick utilities.
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';
import St from 'gi://St';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import {call, fmtBytes, fmtDur, fmtShort, openWindow, spawn} from './client.js';

const STATUS_EVERY_S = 5;
const STATUS_OPEN_EVERY_S = 2;
const MEMORY_EVERY_S = 30;

/** Memory kinds in Kind::ALL order, with their colors. */
const KINDS = [
    {key: 'app', label: 'Apps', color: '#62a0ea'},
    {key: 'docker', label: 'Docker', color: '#1c71d8'},
    {key: 'desktop', label: 'Desktop', color: '#c061cb'},
    {key: 'system', label: 'System', color: '#e5a50a'},
    {key: 'kernel', label: 'Kernel', color: '#77767b'},
];

const now = () => Math.floor(Date.now() / 1000);

/** A non-activatable popup row holding arbitrary content. */
function holder(styleClass = '') {
    // reactive:false would render the whole row as "insensitive" (greyed out); instead keep it
    // reactive but not activatable or highlighted, so only the buttons inside respond.
    const item = new PopupMenu.PopupBaseMenuItem({activate: false, hover: false, can_focus: false, style_class: `kmd-row ${styleClass}`});
    return item;
}

function iconButton(iconName, label, onClick, styleClass = 'kmd-chip') {
    const box = new St.BoxLayout({style_class: 'kmd-chip-box'});
    box.add_child(new St.Icon({icon_name: iconName, icon_size: 14}));
    if (label)
        box.add_child(new St.Label({text: label, y_align: Clutter.ActorAlign.CENTER}));
    const b = new St.Button({style_class: styleClass, child: box, can_focus: true, accessible_name: label || iconName});
    b.connect('clicked', onClick);
    return b;
}

export const KmdIndicator = GObject.registerClass(
class KmdIndicator extends PanelMenu.Button {
    _init(ext, island) {
        super._init(0.5, 'killMyDocker', false);
        this._ext = ext;
        this._island = island;
        this._snap = null;
        this._mem = null;
        this._err = null;
        this._memAt = 0;
        this._busy = false;
        this._cancel = new Gio.Cancellable();
        this._kmdIcon = Gio.FileIcon.new(Gio.File.new_for_path(`${ext.path}/icons/kmd-symbolic.svg`));

        // ---- panel button: [icon] 5.2G · [docker] 1.1G [2 idle]
        const box = new St.BoxLayout({style_class: 'kmd-panel-box'});
        this._panelIcon = new St.Icon({gicon: this._kmdIcon, style_class: 'system-status-icon kmd-panel-icon'});
        this._ramLabel = new St.Label({text: '…', y_align: Clutter.ActorAlign.CENTER, style_class: 'kmd-panel-label'});
        this._dockerLabel = new St.Label({text: '', y_align: Clutter.ActorAlign.CENTER, style_class: 'kmd-panel-label kmd-panel-docker'});
        this._idleBadge = new St.Label({text: '', y_align: Clutter.ActorAlign.CENTER, style_class: 'kmd-panel-badge', visible: false});
        box.add_child(this._panelIcon);
        box.add_child(this._ramLabel);
        box.add_child(this._dockerLabel);
        box.add_child(this._idleBadge);
        this.add_child(box);

        this.menu.box.add_style_class_name('kmd-menu');
        this._buildMenu();

        this.menu.connect('open-state-changed', (_m, open) => {
            if (open) {
                this._memAt = 0; // fresh numbers when the popup opens
                this._refresh();
            }
            this._schedule();
        });

        this._refresh();
        this._schedule();
    }

    // ------------------------------------------------------------ polling

    _schedule() {
        if (this._timer)
            GLib.source_remove(this._timer);
        const every = this.menu.isOpen ? STATUS_OPEN_EVERY_S : STATUS_EVERY_S;
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, every, () => {
            this._refresh();
            return GLib.SOURCE_CONTINUE;
        });
    }

    async _refresh() {
        if (this._busy)
            return;
        this._busy = true;
        try {
            const r = await call({cmd: 'status'}, this._cancel);
            this._snap = r.status;
            this._err = null;
            const memEvery = this.menu.isOpen ? 10 : MEMORY_EVERY_S;
            if (now() - this._memAt >= memEvery) {
                const m = await call({cmd: 'memory_cached'}, this._cancel);
                this._mem = m.memory ?? this._mem;
                this._memAt = now();
            }
        } catch (e) {
            if (this._cancel.is_cancelled())
                return;
            this._err = e.message;
        } finally {
            this._busy = false;
        }
        this._render();
    }

    async _do(request, okText) {
        try {
            await call(request, this._cancel);
            if (okText)
                this._island.notify({kind: 'stopped', title: okText});
        } catch (e) {
            this._island.notify({kind: 'error', title: 'killMyDocker', body: e.message});
        }
        this._refresh();
    }

    // ------------------------------------------------------------ menu skeleton

    _buildMenu() {
        // Header: title + service state
        const head = holder('kmd-head');
        const headBox = new St.BoxLayout({x_expand: true});
        const titleIcon = new St.Icon({gicon: this._kmdIcon, icon_size: 18, style_class: 'kmd-head-icon'});
        const title = new St.Label({text: 'killMyDocker', style_class: 'kmd-head-title', y_align: Clutter.ActorAlign.CENTER, x_expand: true});
        this._modePill = new St.Label({style_class: 'kmd-pill', y_align: Clutter.ActorAlign.CENTER});
        headBox.add_child(titleIcon);
        headBox.add_child(title);
        headBox.add_child(this._modePill);
        head.add_child(headBox);
        this.menu.addMenuItem(head);

        // Warnings (memory pressure, service down)
        this._warnItem = holder('kmd-warn');
        this._warnBox = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true});
        this._warnItem.add_child(this._warnBox);
        this.menu.addMenuItem(this._warnItem);

        // Memory card
        this._memItem = holder('kmd-card');
        const mem = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true, style_class: 'kmd-card-box'});
        const memTop = new St.BoxLayout();
        memTop.add_child(new St.Label({text: 'MEMORY', style_class: 'kmd-section', x_expand: true}));
        this._memAvail = new St.Label({style_class: 'kmd-dim'});
        memTop.add_child(this._memAvail);
        this._memBig = new St.Label({style_class: 'kmd-big'});
        this._bar = new St.BoxLayout({style_class: 'kmd-bar', x_expand: true});
        this._legend = new St.BoxLayout({style_class: 'kmd-legend'});
        this._top = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, style_class: 'kmd-top'});
        mem.add_child(memTop);
        mem.add_child(this._memBig);
        mem.add_child(this._bar);
        mem.add_child(this._legend);
        mem.add_child(this._top);
        this._memItem.add_child(mem);
        this.menu.addMenuItem(this._memItem);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Docker section
        this._dockerHead = holder('kmd-docker-head');
        const dh = new St.BoxLayout({x_expand: true});
        dh.add_child(new St.Label({text: 'DOCKER', style_class: 'kmd-section', x_expand: true, y_align: Clutter.ActorAlign.CENTER}));
        this._dockerSummary = new St.Label({style_class: 'kmd-dim', y_align: Clutter.ActorAlign.CENTER});
        dh.add_child(this._dockerSummary);
        this._dockerHead.add_child(dh);
        this.menu.addMenuItem(this._dockerHead);

        this._projects = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._projects);

        this._stoppedMenu = new PopupMenu.PopupSubMenuMenuItem('Stopped');
        this.menu.addMenuItem(this._stoppedMenu);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Utilities
        const utils = holder('kmd-utils');
        const ub = new St.BoxLayout({x_expand: true, style_class: 'kmd-utils-box'});
        this._stopIdleBtn = iconButton('edit-clear-all-symbolic', 'Stop idle', () => {
            this.menu.close();
            this._do({cmd: 'stop_all_idle'}, 'Stopped all idle projects');
        }, 'kmd-chip warn');
        ub.add_child(iconButton('view-list-symbolic', 'Projects', () => {
            this.menu.close();
            openWindow('projects');
        }));
        ub.add_child(iconButton('speedometer-symbolic', 'Memory', () => {
            this.menu.close();
            openWindow('memory');
        }));
        ub.add_child(iconButton('emblem-system-symbolic', 'Settings', () => {
            this.menu.close();
            openWindow('settings');
        }));
        ub.add_child(this._stopIdleBtn);
        this._startSvcBtn = iconButton('media-playback-start-symbolic', 'Start service', () => {
            spawn(['systemctl', '--user', 'start', 'kmd.service']);
            this._island.notify({kind: 'info', title: 'Starting the kmd service…'});
            GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => {
                this._refresh();
                return GLib.SOURCE_REMOVE;
            });
        }, 'kmd-chip warn');
        ub.add_child(this._startSvcBtn);
        utils.add_child(ub);
        this.menu.addMenuItem(utils);
    }

    // ------------------------------------------------------------ render

    _render() {
        const snap = this._snap, mem = this._mem;

        // Panel
        const running = snap ? snap.projects.filter(p => p.state !== 'stopped') : [];
        const dockerMem = running.reduce((a, p) => a + (p.mem || 0), 0);
        const idle = snap ? snap.projects.filter(p => p.is_idle) : [];
        // RAM in use (GiB, the percentage is what perfmon-style monitors already show) and what
        // the running Docker projects hold.
        this._ramLabel.text = this._err ? 'kmd off' : mem ? fmtShort(mem.used) : '…';
        this._dockerLabel.text = this._err || !snap ? '' : `Docker ${running.length ? fmtShort(dockerMem) : '0'}`;
        this.accessible_name = this._err ? 'killMyDocker: service not running'
            : `killMyDocker: ${mem ? fmtBytes(mem.used) : ''} RAM in use, Docker ${fmtBytes(dockerMem)} in ${running.length} projects`;
        this._idleBadge.text = `${idle.length} idle`;
        this._idleBadge.visible = idle.length > 0;
        const memWarn = mem?.warnings?.length > 0;
        this._panelIcon.style_class = `system-status-icon kmd-panel-icon${this._err ? ' off' : memWarn ? ' crit' : idle.length ? ' warn' : ''}`;

        if (!this.menu.isOpen)
            return;

        // Header + warnings
        this._modePill.text = this._err ? 'offline' : snap ? `${snap.mode} · ${snap.idle_hours}h` : '';
        this._warnBox.destroy_all_children();
        const warnings = [...(this._err ? [this._err] : []), ...(mem?.warnings ?? [])];
        for (const w of warnings) {
            const row = new St.BoxLayout({style_class: 'kmd-warn-row'});
            row.add_child(new St.Icon({icon_name: 'dialog-warning-symbolic', icon_size: 14}));
            const l = new St.Label({text: w, x_expand: true});
            l.clutter_text.line_wrap = true;
            row.add_child(l);
            this._warnBox.add_child(row);
        }
        this._warnItem.visible = warnings.length > 0;
        this._startSvcBtn.visible = !!this._err;

        this._renderMemory(mem);
        this._renderDocker(snap, running, idle);
    }

    _renderMemory(mem) {
        this._memItem.visible = !!mem;
        if (!mem)
            return;
        this._memBig.text = `${fmtBytes(mem.used)} of ${fmtBytes(mem.total)}`;
        this._memAvail.text = `${fmtBytes(mem.available)} free`;

        // Segmented bar by kind, scaled to total RAM; the rest is free.
        const byKind = KINDS.map(k => mem.groups.filter(g => g.kind === k.key).reduce((a, g) => a + g.bytes, 0));
        this._bar.destroy_all_children();
        const W = 300;
        let used = 0;
        KINDS.forEach((k, i) => {
            const w = Math.round(W * byKind[i] / mem.total);
            if (w < 2)
                return;
            used += w;
            this._bar.add_child(new St.Widget({width: w, style_class: 'kmd-seg', style: `background-color: ${k.color};`}));
        });
        this._bar.add_child(new St.Widget({width: Math.max(0, W - used), style_class: 'kmd-seg free'}));

        this._legend.destroy_all_children();
        KINDS.forEach((k, i) => {
            if (!byKind[i])
                return;
            const it = new St.BoxLayout({style_class: 'kmd-legend-item'});
            it.add_child(new St.Widget({style_class: 'kmd-legend-dot', style: `background-color: ${k.color};`, y_align: Clutter.ActorAlign.CENTER}));
            it.add_child(new St.Label({text: `${k.label} ${fmtShort(byKind[i])}`}));
            this._legend.add_child(it);
        });

        // Biggest consumers
        this._top.destroy_all_children();
        for (const g of mem.groups.filter(x => x.kind !== 'kernel').slice(0, 5)) {
            const row = new St.BoxLayout({style_class: 'kmd-top-row'});
            const gicon = g.icon ? Gio.ThemedIcon.new_with_default_fallbacks(g.icon)
                : Gio.ThemedIcon.new(g.kind === 'docker' ? 'application-x-executable-symbolic' : 'application-x-executable-symbolic');
            row.add_child(new St.Icon({gicon: g.kind === 'docker' ? this._kmdIcon : gicon, icon_size: 16, style_class: 'kmd-top-icon'}));
            row.add_child(new St.Label({text: g.name, x_expand: true, style_class: 'kmd-top-name', y_align: Clutter.ActorAlign.CENTER}));
            if (g.growth_1h && Math.abs(g.growth_1h) >= 50 * 1048576) {
                const up = g.growth_1h > 0;
                row.add_child(new St.Label({
                    text: `${up ? '▲' : '▼'} ${fmtShort(Math.abs(g.growth_1h))}`,
                    style_class: `kmd-growth ${up ? 'up' : 'down'}`,
                    y_align: Clutter.ActorAlign.CENTER,
                }));
            }
            row.add_child(new St.Label({text: fmtBytes(g.bytes), style_class: 'kmd-top-bytes', y_align: Clutter.ActorAlign.CENTER}));
            this._top.add_child(row);
        }
    }

    _renderDocker(snap, running, idle) {
        this._projects.removeAll();
        this._dockerHead.visible = !!snap;
        if (!snap) {
            this._stoppedMenu.visible = false;
            this._stopIdleBtn.visible = false;
            return;
        }
        const total = running.reduce((a, p) => a + (p.mem || 0), 0);
        this._dockerSummary.text = running.length
            ? `${fmtBytes(total)} in ${running.length} running${idle.length ? ` · ${idle.length} idle` : ''}`
            : 'nothing running';

        const t = now();
        for (const p of running) {
            const item = holder('kmd-project');
            const row = new St.BoxLayout({x_expand: true, style_class: 'kmd-project-box'});
            const state = p.is_idle ? 'idle' : p.ignored ? 'ignored' : p.state === 'partial' ? 'partial' : 'running';
            row.add_child(new St.Widget({style_class: `kmd-state ${state}`, y_align: Clutter.ActorAlign.CENTER}));
            const texts = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true});
            texts.add_child(new St.Label({text: p.name, style_class: 'kmd-project-name'}));
            const bits = [fmtBytes(p.mem)];
            if (p.idle_secs != null)
                bits.push(p.is_idle ? `idle ${fmtDur(p.idle_secs)}` : `active ${fmtDur(p.idle_secs)} ago`);
            if (p.snoozed_until)
                bits.push(`snoozed ${fmtDur(p.snoozed_until - t)}`);
            if (p.ignored)
                bits.push('never alerts');
            texts.add_child(new St.Label({text: bits.join(' · '), style_class: 'kmd-dim'}));
            row.add_child(texts);

            const actions = new St.BoxLayout({style_class: 'kmd-project-actions', y_align: Clutter.ActorAlign.CENTER});
            if (p.snoozed_until) {
                actions.add_child(iconButton('alarm-symbolic', '', () => this._do({cmd: 'unsnooze', project: p.name}), 'kmd-icon-btn'));
            } else if (!p.ignored) {
                actions.add_child(iconButton('alarm-symbolic', '', () =>
                    this._do({cmd: 'snooze', project: p.name, hours: 4}, `Snoozed ${p.name} for 4 hours`), 'kmd-icon-btn'));
            }
            actions.add_child(iconButton('media-playback-stop-symbolic', 'Stop', () =>
                this._do({cmd: 'stop', project: p.name}, `Stopped ${p.name}`), 'kmd-chip danger'));
            row.add_child(actions);
            item.add_child(row);
            this._projects.addMenuItem(item);
        }
        if (!running.length) {
            const item = holder('kmd-empty');
            item.add_child(new St.Label({text: 'No Docker projects are running.', style_class: 'kmd-dim'}));
            this._projects.addMenuItem(item);
        }

        const stopped = snap.projects.filter(p => p.state === 'stopped');
        this._stoppedMenu.visible = stopped.length > 0;
        this._stoppedMenu.label.text = `Stopped (${stopped.length})`;
        this._stoppedMenu.menu.removeAll();
        for (const p of stopped) {
            const it = new PopupMenu.PopupImageMenuItem(`Start ${p.name}`, 'media-playback-start-symbolic');
            it.connect('activate', () => this._do({cmd: 'start', project: p.name}, `Started ${p.name}`));
            this._stoppedMenu.menu.addMenuItem(it);
        }

        this._stopIdleBtn.visible = idle.length > 0;
        if (idle.length) {
            const freed = idle.reduce((a, p) => a + (p.mem || 0), 0);
            this._stopIdleBtn.child.get_last_child().text = `Stop ${idle.length} idle · ${fmtShort(freed)}`;
        }
    }

    destroy() {
        this._cancel.cancel();
        if (this._timer)
            GLib.source_remove(this._timer);
        this._timer = 0;
        super.destroy();
    }
});
