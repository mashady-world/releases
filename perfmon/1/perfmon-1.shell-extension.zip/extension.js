import GObject from 'gi://GObject';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

const INTERVAL_SEC = 2;
const OVERLAY_MARGIN = 16;           // distance from the screen edge (px)
const OVERLAY_CORNER = 'top-right';  // top-left | top-right | bottom-left | bottom-right
const CONFIG_PATH = GLib.build_filenamev([GLib.get_user_config_dir(), 'perfmon-mashady.json']);

const decoder = new TextDecoder();

function readText(path) {
    try {
        const [ok, bytes] = GLib.file_get_contents(path);
        return ok ? decoder.decode(bytes) : '';
    } catch (e) {
        return '';
    }
}

function fmtBytes(b) {
    const units = ['B', 'K', 'M', 'G', 'T'];
    let i = 0;
    while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
    return `${b.toFixed(i > 1 ? 1 : 0)}${units[i]}`;
}

function fmtSpeed(bps) {
    return `${fmtBytes(bps)}/s`;
}

class Sampler {
    constructor() {
        this._prevCpu = null;
        this._prevNet = null;
        this._prevTime = 0;
        this._tempPath = this._findTempSensor();
    }

    _findTempSensor() {
        // Prefer CPU sensors (Intel coretemp / AMD k10temp), fall back to thermal_zone0
        try {
            const base = '/sys/class/hwmon';
            const dir = Gio.File.new_for_path(base);
            const en = dir.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = en.next_file(null)) !== null) {
                const p = `${base}/${info.get_name()}`;
                const name = readText(`${p}/name`).trim();
                if (['coretemp', 'k10temp', 'zenpower'].includes(name)) {
                    for (const f of ['temp1_input', 'temp2_input']) {
                        if (readText(`${p}/${f}`).trim() !== '')
                            return `${p}/${f}`;
                    }
                }
            }
        } catch (e) { /* ignore */ }
        if (readText('/sys/class/thermal/thermal_zone0/temp').trim() !== '')
            return '/sys/class/thermal/thermal_zone0/temp';
        return null;
    }

    sample() {
        const now = GLib.get_monotonic_time() / 1e6;
        const dt = this._prevTime ? now - this._prevTime : 0;
        const out = {};

        // CPU
        const line = readText('/proc/stat').split('\n', 1)[0].trim().split(/\s+/).slice(1).map(Number);
        const idle = (line[3] || 0) + (line[4] || 0);
        const total = line.slice(0, 8).reduce((a, b) => a + (b || 0), 0);
        if (this._prevCpu) {
            const dT = total - this._prevCpu.total;
            const dI = idle - this._prevCpu.idle;
            out.cpu = dT > 0 ? Math.max(0, Math.min(100, 100 * (1 - dI / dT))) : 0;
        } else {
            out.cpu = 0;
        }
        this._prevCpu = {total, idle};

        // RAM
        const mem = readText('/proc/meminfo');
        const mt = parseInt((mem.match(/MemTotal:\s+(\d+)/) || [])[1] || '0') * 1024;
        const ma = parseInt((mem.match(/MemAvailable:\s+(\d+)/) || [])[1] || '0') * 1024;
        out.ramTotal = mt;
        out.ramUsed = mt - ma;
        out.ram = mt > 0 ? 100 * (mt - ma) / mt : 0;

        // Disk (root filesystem)
        try {
            const info = Gio.File.new_for_path('/').query_filesystem_info('filesystem::size,filesystem::free', null);
            const size = info.get_attribute_uint64('filesystem::size');
            const free = info.get_attribute_uint64('filesystem::free');
            out.diskTotal = size;
            out.diskUsed = size - free;
            out.disk = size > 0 ? 100 * (size - free) / size : 0;
        } catch (e) {
            out.diskTotal = out.diskUsed = out.disk = 0;
        }

        // Temperature
        out.temp = null;
        if (this._tempPath) {
            const t = parseInt(readText(this._tempPath).trim());
            if (!isNaN(t)) out.temp = t / 1000;
        }

        // Network
        let rx = 0, tx = 0;
        for (const l of readText('/proc/net/dev').split('\n').slice(2)) {
            const [iface, rest] = l.split(':');
            if (!rest || iface.trim() === 'lo') continue;
            const c = rest.trim().split(/\s+/).map(Number);
            rx += c[0] || 0;
            tx += c[8] || 0;
        }
        if (this._prevNet && dt > 0) {
            out.down = Math.max(0, (rx - this._prevNet.rx) / dt);
            out.up = Math.max(0, (tx - this._prevNet.tx) / dt);
        } else {
            out.down = out.up = 0;
        }
        this._prevNet = {rx, tx};
        this._prevTime = now;

        return out;
    }
}

const PerfIndicator = GObject.registerClass(
class PerfIndicator extends PanelMenu.Button {
    _init(ext) {
        super._init(0.0, 'Perf Monitor', false);
        this._ext = ext;
        this._sampler = new Sampler();
        this._overlay = null;
        this._timeoutId = 0;

        this._label = new St.Label({
            text: '...',
            y_align: Clutter.ActorAlign.CENTER,
            style: 'font-feature-settings: "tnum"; padding: 0 4px;',
        });
        this.add_child(this._label);

        // Dropdown rows
        this._rows = {};
        for (const key of ['cpu', 'ram', 'disk', 'temp', 'net']) {
            const item = new PopupMenu.PopupMenuItem('', {reactive: false, can_focus: false});
            this.menu.addMenuItem(item);
            this._rows[key] = item;
        }

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._overlaySwitch = new PopupMenu.PopupSwitchMenuItem('Show overlay on screen', this._loadConfig().overlay);
        this._overlaySwitch.connect('toggled', (_item, state) => {
            this._setOverlay(state);
            this._saveConfig({overlay: state});
        });
        this.menu.addMenuItem(this._overlaySwitch);

        if (this._overlaySwitch.state)
            this._setOverlay(true);

        this._tick();
        this._timeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, INTERVAL_SEC, () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _loadConfig() {
        try {
            return Object.assign({overlay: false}, JSON.parse(readText(CONFIG_PATH) || '{}'));
        } catch (e) {
            return {overlay: false};
        }
    }

    _saveConfig(cfg) {
        try {
            GLib.file_set_contents(CONFIG_PATH, JSON.stringify(cfg));
        } catch (e) { /* ignore */ }
    }

    _setOverlay(on) {
        if (on && !this._overlay) {
            this._overlay = new St.Label({
                text: '',
                reactive: false,           // clicks pass through to the app below
                can_focus: false,
                track_hover: false,
                style: 'color: white; font-family: monospace; font-size: 11pt; font-weight: bold; ' +
                       'background-color: rgba(0,0,0,0.35); border-radius: 8px; padding: 4px 10px; ' +
                       'text-shadow: 1px 1px 2px black;',
            });
            Main.layoutManager.addChrome(this._overlay, {
                affectsInputRegion: false,
                affectsStruts: false,
                trackFullscreen: false,    // stays visible even over fullscreen apps
            });
            this._monitorsId = Main.layoutManager.connect('monitors-changed', () => this._placeOverlay());
            this._tick();
        } else if (!on && this._overlay) {
            if (this._monitorsId) {
                Main.layoutManager.disconnect(this._monitorsId);
                this._monitorsId = 0;
            }
            Main.layoutManager.removeChrome(this._overlay);
            this._overlay.destroy();
            this._overlay = null;
        }
    }

    _placeOverlay() {
        if (!this._overlay) return;
        const m = Main.layoutManager.primaryMonitor;
        if (!m) return;
        const [w, h] = this._overlay.get_size();
        const right = OVERLAY_CORNER.endsWith('right');
        const bottom = OVERLAY_CORNER.startsWith('bottom');
        const x = right ? m.x + m.width - w - OVERLAY_MARGIN : m.x + OVERLAY_MARGIN;
        const y = bottom ? m.y + m.height - h - OVERLAY_MARGIN : m.y + OVERLAY_MARGIN + Main.panel.height;
        this._overlay.set_position(Math.round(x), Math.round(y));
    }

    _tick() {
        const s = this._sampler.sample();
        const temp = s.temp !== null ? `${Math.round(s.temp)}°C` : null;

        const short = [`CPU ${s.cpu.toFixed(0)}%`, `RAM ${s.ram.toFixed(0)}%`];
        if (temp) short.push(temp);
        this._label.set_text(short.join('  '));

        if (this.menu.isOpen) {
            this._rows.cpu.label.set_text(`CPU:   ${s.cpu.toFixed(1)}%`);
            this._rows.ram.label.set_text(`RAM:   ${fmtBytes(s.ramUsed)} / ${fmtBytes(s.ramTotal)}  (${s.ram.toFixed(0)}%)`);
            this._rows.disk.label.set_text(`Disk:  ${fmtBytes(s.diskUsed)} / ${fmtBytes(s.diskTotal)}  (${s.disk.toFixed(0)}%)`);
            this._rows.temp.label.set_text(`Temp:  ${temp ?? 'N/A'}`);
            this._rows.net.label.set_text(`Net:   ↓ ${fmtSpeed(s.down)}   ↑ ${fmtSpeed(s.up)}`);
        }

        if (this._overlay) {
            const parts = [
                `CPU ${s.cpu.toFixed(0)}%`,
                `RAM ${s.ram.toFixed(0)}%`,
                `DISK ${s.disk.toFixed(0)}%`,
            ];
            if (temp) parts.push(temp);
            parts.push(`↓${fmtSpeed(s.down)} ↑${fmtSpeed(s.up)}`);
            this._overlay.set_text(parts.join('  |  '));
            this._placeOverlay();
        }
    }

    destroy() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        this._setOverlay(false);
        super.destroy();
    }
});

export default class PerfMonitorExtension extends Extension {
    enable() {
        this._indicator = new PerfIndicator(this);
        Main.panel.addToStatusArea(this.uuid, this._indicator, 0, 'right');
    }

    disable() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
