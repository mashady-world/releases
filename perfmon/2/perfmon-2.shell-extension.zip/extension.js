// Perf Monitor: CPU / RAM / Temp in the top bar, a popup with every metric, and an optional
// floating overlay you can drag anywhere (right-click it to hide it).
import GObject from 'gi://GObject';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

const INTERVAL_SEC = 2;
const OVERLAY_MARGIN = 16;           // distance from the screen edge (px)
const OVERLAY_CORNER = 'top-right';  // default corner until you drag it: top-left | top-right | bottom-left | bottom-right
const OVERLAY_WIDTH = 250;           // px, fixed so the box doesn't jitter
const OVERLAY_BAR = OVERLAY_WIDTH - 28;
const MENU_BAR = 300;
const CONFIG_PATH = GLib.build_filenamev([GLib.get_user_config_dir(), 'perfmon-mashady.json']);
const DEFAULT_CONFIG = {overlay: false, pos: null, panelValues: true};

/** Per-metric look and thresholds (percent, or °C for temp). */
const METRICS = {
    cpu: {label: 'CPU', icon: 'pm-cpu', accent: '#62a0ea', warn: 50, crit: 80},
    ram: {label: 'Memory', icon: 'pm-ram', accent: '#c061cb', warn: 70, crit: 85},
    temp: {label: 'Temperature', icon: 'pm-temp', accent: '#33c7de', warn: 70, crit: 85},
    disk: {label: 'Storage', icon: 'pm-disk', accent: '#57e389', warn: 80, crit: 90},
    net: {label: 'Network', icon: 'pm-net', accent: '#f9f06b'},
};
const LEVEL_COLOR = {warn: '#f5a623', crit: '#ff453a'};

const decoder = new TextDecoder();

function readText(path) {
    try {
        const [ok, bytes] = GLib.file_get_contents(path);
        return ok ? decoder.decode(bytes) : '';
    } catch (e) {
        return '';
    }
}

function fmtBytes(b) {
    const units = ['B', 'K', 'M', 'G', 'T'];
    let i = 0;
    while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
    return `${b.toFixed(i > 1 ? 1 : 0)}${units[i]}`;
}

function fmtSpeed(bps) {
    return `${fmtBytes(bps)}/s`;
}

function level(key, v) {
    const m = METRICS[key];
    if (v === null || v === undefined || m.warn === undefined) return 'ok';
    return v >= m.crit ? 'crit' : v >= m.warn ? 'warn' : 'ok';
}

class Sampler {
    constructor() {
        this._prevCpu = null;
        this._prevNet = null;
        this._prevTime = 0;
        this._tempPath = this._findTempSensor();
    }

    _findTempSensor() {
        // Prefer CPU sensors (Intel coretemp / AMD k10temp), fall back to thermal_zone0
        try {
            const base = '/sys/class/hwmon';
            const dir = Gio.File.new_for_path(base);
            const en = dir.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = en.next_file(null)) !== null) {
                const p = `${base}/${info.get_name()}`;
                const name = readText(`${p}/name`).trim();
                if (['coretemp', 'k10temp', 'zenpower'].includes(name)) {
                    for (const f of ['temp1_input', 'temp2_input']) {
                        if (readText(`${p}/${f}`).trim() !== '')
                            return `${p}/${f}`;
                    }
                }
            }
        } catch (e) { /* ignore */ }
        if (readText('/sys/class/thermal/thermal_zone0/temp').trim() !== '')
            return '/sys/class/thermal/thermal_zone0/temp';
        return null;
    }

    sample() {
        const now = GLib.get_monotonic_time() / 1e6;
        const dt = this._prevTime ? now - this._prevTime : 0;
        const out = {};

        // CPU
        const line = readText('/proc/stat').split('\n', 1)[0].trim().split(/\s+/).slice(1).map(Number);
        const idle = (line[3] || 0) + (line[4] || 0);
        const total = line.slice(0, 8).reduce((a, b) => a + (b || 0), 0);
        if (this._prevCpu) {
            const dT = total - this._prevCpu.total;
            const dI = idle - this._prevCpu.idle;
            out.cpu = dT > 0 ? Math.max(0, Math.min(100, 100 * (1 - dI / dT))) : 0;
        } else {
            out.cpu = 0;
        }
        this._prevCpu = {total, idle};

        // RAM
        const mem = readText('/proc/meminfo');
        const mt = parseInt((mem.match(/MemTotal:\s+(\d+)/) || [])[1] || '0') * 1024;
        const ma = parseInt((mem.match(/MemAvailable:\s+(\d+)/) || [])[1] || '0') * 1024;
        out.ramTotal = mt;
        out.ramUsed = mt - ma;
        out.ram = mt > 0 ? 100 * (mt - ma) / mt : 0;

        // Disk (root filesystem)
        try {
            const info = Gio.File.new_for_path('/').query_filesystem_info('filesystem::size,filesystem::free', null);
            const size = info.get_attribute_uint64('filesystem::size');
            const free = info.get_attribute_uint64('filesystem::free');
            out.diskTotal = size;
            out.diskUsed = size - free;
            out.disk = size > 0 ? 100 * (size - free) / size : 0;
        } catch (e) {
            out.diskTotal = out.diskUsed = out.disk = 0;
        }

        // Temperature
        out.temp = null;
        if (this._tempPath) {
            const t = parseInt(readText(this._tempPath).trim());
            if (!isNaN(t)) out.temp = t / 1000;
        }

        // Network
        let rx = 0, tx = 0;
        for (const l of readText('/proc/net/dev').split('\n').slice(2)) {
            const [iface, rest] = l.split(':');
            if (!rest || iface.trim() === 'lo') continue;
            const c = rest.trim().split(/\s+/).map(Number);
            rx += c[0] || 0;
            tx += c[8] || 0;
        }
        if (this._prevNet && dt > 0) {
            out.down = Math.max(0, (rx - this._prevNet.rx) / dt);
            out.up = Math.max(0, (tx - this._prevNet.tx) / dt);
        } else {
            out.down = out.up = 0;
        }
        this._prevNet = {rx, tx};
        this._prevTime = now;

        return out;
    }
}

// ---------------------------------------------------------------- widgets

/** A metric block: [icon] Name ........ value / sub line / progress bar. */
function makeMetric(key, gicon, barWidth, {bar = true, sub = true} = {}) {
    const m = METRICS[key];
    const box = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, style_class: 'pm-metric', x_expand: true});
    const top = new St.BoxLayout({style_class: 'pm-metric-top'});
    const icon = new St.Icon({gicon: gicon(m.icon), icon_size: 14, style_class: 'pm-metric-icon', style: `color: ${m.accent};`});
    const name = new St.Label({text: m.label, style_class: 'pm-metric-name', x_expand: true, y_align: Clutter.ActorAlign.CENTER});
    const value = new St.Label({text: '…', style_class: 'pm-metric-value', y_align: Clutter.ActorAlign.CENTER});
    top.add_child(icon);
    top.add_child(name);
    top.add_child(value);
    box.add_child(top);

    const subLabel = sub ? new St.Label({text: '', style_class: 'pm-metric-sub'}) : null;
    if (subLabel) box.add_child(subLabel);

    let fill = null;
    if (bar) {
        const track = new St.Widget({width: barWidth, style_class: 'pm-track'});
        fill = new St.Widget({width: 0, style_class: 'pm-fill', style: `background-color: ${m.accent};`});
        track.add_child(fill);
        box.add_child(track);
    }

    return {
        actor: box,
        set({text, subText = '', pct = null, lvl = 'ok'}) {
            value.text = text;
            value.style = lvl === 'ok' ? '' : `color: ${LEVEL_COLOR[lvl]};`;
            if (subLabel) subLabel.text = subText;
            if (fill && pct !== null) {
                fill.width = Math.round(barWidth * Math.max(0, Math.min(100, pct)) / 100);
                fill.style = `background-color: ${lvl === 'ok' ? m.accent : LEVEL_COLOR[lvl]};`;
            }
        },
    };
}

/** Fills every metric block in `blocks` from one sample. */
function renderMetrics(blocks, s) {
    blocks.cpu.set({text: `${s.cpu.toFixed(0)}%`, pct: s.cpu, lvl: level('cpu', s.cpu)});
    blocks.ram.set({
        text: `${s.ram.toFixed(0)}%`, pct: s.ram, lvl: level('ram', s.ram),
        subText: `${fmtBytes(s.ramUsed)} of ${fmtBytes(s.ramTotal)}`,
    });
    blocks.temp.set(s.temp === null
        ? {text: 'N/A', pct: 0}
        : {text: `${Math.round(s.temp)}°C`, pct: s.temp, lvl: level('temp', s.temp)});
    blocks.disk.set({
        text: `${s.disk.toFixed(0)}%`, pct: s.disk, lvl: level('disk', s.disk),
        subText: `${fmtBytes(s.diskUsed)} used · ${fmtBytes(s.diskTotal - s.diskUsed)} free`,
    });
    blocks.net.set({text: `↓ ${fmtSpeed(s.down)}   ↑ ${fmtSpeed(s.up)}`});
}

function buildMetrics(parent, gicon, barWidth) {
    const blocks = {
        cpu: makeMetric('cpu', gicon, barWidth, {sub: false}),
        ram: makeMetric('ram', gicon, barWidth),
        temp: makeMetric('temp', gicon, barWidth, {sub: false}),
        disk: makeMetric('disk', gicon, barWidth),
        net: makeMetric('net', gicon, barWidth, {bar: false, sub: false}),
    };
    for (const b of Object.values(blocks)) parent.add_child(b.actor);
    return blocks;
}

function holder(styleClass = '') {
    return new PopupMenu.PopupBaseMenuItem({activate: false, hover: false, can_focus: false, style_class: `pm-row ${styleClass}`});
}

// ---------------------------------------------------------------- indicator

const PerfIndicator = GObject.registerClass(
class PerfIndicator extends PanelMenu.Button {
    _init(ext) {
        super._init(0.5, 'Perf Monitor', false);
        this._ext = ext;
        this._sampler = new Sampler();
        this._overlay = null;
        this._timeoutId = 0;
        this._last = null;
        this._icons = {};

        const cfg = this._loadConfig();

        // ---- panel: [cpu] 5%  [ram] 42%  │ [temp] 48°
        const box = new St.BoxLayout({style_class: 'pm-panel-box'});
        this._panelIcon = new St.Icon({gicon: this._gicon('pm-monitor'), style_class: 'system-status-icon pm-panel-main'});
        box.add_child(this._panelIcon);
        this._panel = {};
        for (const key of ['cpu', 'ram', 'temp']) {
            const item = new St.BoxLayout({style_class: `pm-panel-item${key === 'temp' ? ' pm-panel-sep' : ''}`});
            const icon = new St.Icon({gicon: this._gicon(METRICS[key].icon), style_class: 'pm-panel-icon', y_align: Clutter.ActorAlign.CENTER});
            const label = new St.Label({text: '…', style_class: 'pm-panel-label', y_align: Clutter.ActorAlign.CENTER});
            item.add_child(icon);
            item.add_child(label);
            box.add_child(item);
            this._panel[key] = {item, icon, label};
        }
        this.add_child(box);
        this._applyPanelMode(cfg.panelValues);

        // ---- popup
        this.menu.box.add_style_class_name('pm-menu');

        const head = holder('pm-head');
        const headBox = new St.BoxLayout({x_expand: true});
        headBox.add_child(new St.Icon({gicon: this._gicon('pm-monitor'), icon_size: 18, style_class: 'pm-head-icon'}));
        headBox.add_child(new St.Label({text: 'Perf Monitor', style_class: 'pm-head-title', x_expand: true, y_align: Clutter.ActorAlign.CENTER}));
        headBox.add_child(new St.Label({text: `every ${INTERVAL_SEC}s`, style_class: 'pm-pill', y_align: Clutter.ActorAlign.CENTER}));
        head.add_child(headBox);
        this.menu.addMenuItem(head);

        const card = holder('pm-card');
        const cardBox = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true, style_class: 'pm-card-box'});
        this._menuBlocks = buildMetrics(cardBox, n => this._gicon(n), MENU_BAR);
        card.add_child(cardBox);
        this.menu.addMenuItem(card);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._valuesSwitch = new PopupMenu.PopupSwitchMenuItem('Numbers in top bar', cfg.panelValues);
        this._valuesSwitch.connect('toggled', (_i, state) => {
            this._saveConfig({panelValues: state});
            this._applyPanelMode(state);
        });
        this.menu.addMenuItem(this._valuesSwitch);

        this._overlaySwitch = new PopupMenu.PopupSwitchMenuItem('Floating overlay on screen', cfg.overlay);
        this._overlaySwitch.connect('toggled', (_i, state) => this._toggleOverlay(state));
        this.menu.addMenuItem(this._overlaySwitch);

        const resetItem = new PopupMenu.PopupMenuItem('Reset overlay position');
        resetItem.connect('activate', () => {
            this._saveConfig({pos: null});
            this._placeOverlay(true);
        });
        this.menu.addMenuItem(resetItem);

        const hint = holder('pm-hint-row');
        hint.add_child(new St.Label({text: 'Drag the overlay to move it · right-click it to hide', style_class: 'pm-hint'}));
        this.menu.addMenuItem(hint);

        this.menu.connect('open-state-changed', (_m, open) => {
            if (open && this._last) renderMetrics(this._menuBlocks, this._last);
        });

        if (cfg.overlay)
            this._toggleOverlay(true);

        this._tick();
        this._timeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, INTERVAL_SEC, () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _gicon(name) {
        if (!this._icons[name])
            this._icons[name] = Gio.FileIcon.new(Gio.File.new_for_path(`${this._ext.path}/icons/${name}-symbolic.svg`));
        return this._icons[name];
    }

    _loadConfig() {
        try {
            return Object.assign({}, DEFAULT_CONFIG, JSON.parse(readText(CONFIG_PATH) || '{}'));
        } catch (e) {
            return {...DEFAULT_CONFIG};
        }
    }

    _saveConfig(cfg) {
        try {
            GLib.file_set_contents(CONFIG_PATH, JSON.stringify(Object.assign(this._loadConfig(), cfg)));
        } catch (e) { /* ignore */ }
    }

    _applyPanelMode(values) {
        this._panelIcon.visible = !values;
        for (const p of Object.values(this._panel)) p.item.visible = values;
    }

    // ------------------------------------------------------------ overlay

    _toggleOverlay(on) {
        this._saveConfig({overlay: on});
        try {
            this._setOverlay(on);
        } catch (e) {
            console.error(`perfmon: overlay failed: ${e}\n${e.stack}`);
            this._destroyOverlay();
            this._saveConfig({overlay: false});
            this._overlaySwitch.setToggleState(false);
            Main.notifyError('Perf Monitor', `Couldn't show the overlay: ${e.message}`);
        }
    }

    _setOverlay(on) {
        if (on && !this._overlay) {
            this._overlay = new St.BoxLayout({
                orientation: Clutter.Orientation.VERTICAL,
                style_class: 'pm-overlay',
                reactive: true,
                track_hover: true,
                width: OVERLAY_WIDTH,
            });

            const head = new St.BoxLayout({style_class: 'pm-ov-head'});
            head.add_child(new St.Widget({style_class: 'pm-live-dot', y_align: Clutter.ActorAlign.CENTER}));
            head.add_child(new St.Label({text: 'SYSTEM', style_class: 'pm-eyebrow', x_expand: true, y_align: Clutter.ActorAlign.CENTER}));
            this._ovClock = new St.Label({text: '', style_class: 'pm-eyebrow pm-dim', y_align: Clutter.ActorAlign.CENTER});
            head.add_child(this._ovClock);
            this._overlay.add_child(head);

            this._ovBlocks = buildMetrics(this._overlay, n => this._gicon(n), OVERLAY_BAR);

            this._overlay.connect('event', (_a, ev) => this._onOverlayEvent(ev));

            Main.layoutManager.addChrome(this._overlay, {
                affectsStruts: false,
                trackFullscreen: false,    // stays visible even over fullscreen apps
            });
            this._monitorsId = Main.layoutManager.connect('monitors-changed', () => this._placeOverlay(true));
            this._placed = false;
            if (this._last) this._renderOverlay(this._last);
            this._placeOverlay(true);
        } else if (!on && this._overlay) {
            this._destroyOverlay();
        }
    }

    _destroyOverlay() {
        this._endDrag(false);
        if (this._monitorsId) {
            Main.layoutManager.disconnect(this._monitorsId);
            this._monitorsId = 0;
        }
        if (this._overlay) {
            Main.layoutManager.removeChrome(this._overlay);
            this._overlay.destroy();
        }
        this._overlay = null;
        this._ovBlocks = null;
        this._ovClock = null;
    }

    // Clutter.DragAction is gone in GNOME 50, so drag by hand: grab the pointer on press,
    // follow motion, save the position on release.
    _onOverlayEvent(ev) {
        const type = ev.type();
        if (type === Clutter.EventType.BUTTON_PRESS) {
            if (ev.get_button() === Clutter.BUTTON_SECONDARY) {
                this._overlaySwitch.setToggleState(false);
                this._toggleOverlay(false);
                return Clutter.EVENT_STOP;
            }
            if (ev.get_button() !== Clutter.BUTTON_PRIMARY) return Clutter.EVENT_PROPAGATE;
            const [px, py] = ev.get_coords();
            const [ax, ay] = this._overlay.get_position();
            this._drag = {dx: px - ax, dy: py - ay};
            this._grab = global.stage.grab(this._overlay);
            this._overlay.add_style_class_name('dragging');
            return Clutter.EVENT_STOP;
        }
        if (type === Clutter.EventType.MOTION && this._drag) {
            const [px, py] = ev.get_coords();
            const [w, h] = this._overlay.get_size();
            const x = Math.max(0, Math.min(px - this._drag.dx, global.stage.width - w));
            const y = Math.max(0, Math.min(py - this._drag.dy, global.stage.height - h));
            this._overlay.set_position(Math.round(x), Math.round(y));
            return Clutter.EVENT_STOP;
        }
        if (type === Clutter.EventType.BUTTON_RELEASE && this._drag) {
            this._endDrag(true);
            return Clutter.EVENT_STOP;
        }
        return Clutter.EVENT_PROPAGATE;
    }

    _endDrag(save) {
        if (!this._drag) return;
        this._drag = null;
        this._grab?.dismiss();
        this._grab = null;
        if (this._overlay) {
            this._overlay.remove_style_class_name('dragging');
            if (save) {
                const [x, y] = this._overlay.get_position();
                this._saveConfig({pos: [Math.round(x), Math.round(y)]});
            }
        }
    }

    _placeOverlay(force = false) {
        if (!this._overlay || (this._placed && !force)) return;
        const [, w] = this._overlay.get_preferred_width(-1);
        const [, h] = this._overlay.get_preferred_height(w);
        const saved = this._loadConfig().pos;
        const mons = Main.layoutManager.monitors;
        const primary = Main.layoutManager.primaryMonitor;
        if (!primary) return;
        let x, y;
        if (saved) {
            // keep it on the monitor it was dropped on, and on-screen if the layout changed
            const m = mons.find(m => saved[0] >= m.x && saved[0] < m.x + m.width &&
                                     saved[1] >= m.y && saved[1] < m.y + m.height) ?? primary;
            x = Math.max(m.x, Math.min(saved[0], m.x + m.width - w));
            y = Math.max(m.y, Math.min(saved[1], m.y + m.height - h));
        } else {
            const m = primary;
            const right = OVERLAY_CORNER.endsWith('right');
            const bottom = OVERLAY_CORNER.startsWith('bottom');
            x = right ? m.x + m.width - w - OVERLAY_MARGIN : m.x + OVERLAY_MARGIN;
            y = bottom ? m.y + m.height - h - OVERLAY_MARGIN : m.y + OVERLAY_MARGIN + Main.panel.height;
        }
        this._overlay.set_position(Math.round(x), Math.round(y));
        this._placed = true;
    }

    _renderOverlay(s) {
        renderMetrics(this._ovBlocks, s);
        this._ovClock.text = GLib.DateTime.new_now_local().format('%H:%M');
    }

    // ------------------------------------------------------------ tick

    _tick() {
        const s = this._sampler.sample();
        this._last = s;

        // Panel
        const vals = {cpu: s.cpu, ram: s.ram, temp: s.temp};
        let worst = 'ok';
        for (const key of ['cpu', 'ram', 'temp']) {
            const v = vals[key];
            const lvl = level(key, v);
            const p = this._panel[key];
            p.item.visible = this._loadPanelValues() && (key !== 'temp' || v !== null);
            p.label.text = v === null ? '' : key === 'temp' ? `${Math.round(v)}°` : `${v.toFixed(0)}%`;
            p.icon.style = lvl === 'ok' ? '' : `color: ${LEVEL_COLOR[lvl]};`;
            p.label.style = lvl === 'ok' ? '' : `color: ${LEVEL_COLOR[lvl]};`;
            if (lvl === 'crit' || (lvl === 'warn' && worst === 'ok')) worst = lvl;
        }
        this._panelIcon.style = worst === 'ok' ? '' : `color: ${LEVEL_COLOR[worst]};`;

        if (this.menu.isOpen)
            renderMetrics(this._menuBlocks, s);

        if (this._overlay) {
            this._renderOverlay(s);
            this._placeOverlay();
        }
    }

    _loadPanelValues() {
        return this._valuesSwitch ? this._valuesSwitch.state : true;
    }

    destroy() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        this._destroyOverlay();
        super.destroy();
    }
});

export default class PerfMonitorExtension extends Extension {
    enable() {
        this._indicator = new PerfIndicator(this);
        Main.panel.addToStatusArea(this.uuid, this._indicator, 0, 'right');
    }

    disable() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
