# quiver.

A ctl. product: a browser extension (Manifest V3) that fills job application forms from your ctl Career data, shows what it matched, and turns every application into progress.

## Install (unpacked)
1. `chrome://extensions` (or `brave://extensions`), turn on Developer mode, Load unpacked, pick this folder.
2. The settings page opens on first install: set the workspace URL and a token (ctl, Career, Tools, scope `autofill`).
3. Open a job application, press Quiver, then Fill form. Scan only previews the matches without touching the page.

## How it works
- Rules come from `GET /api/consumer/autofill` (Bearer `ctl_...`). The last copy is cached in `chrome.storage`, so it keeps working when ctl is down.
- Matching: the rule whose keyword is the longest whole-phrase hit on the field label wins; `exclude` words veto it; `long` rules only fill textareas.
- Fields that already have a value are kept. File uploads and unmatched fields are listed for you. Nothing is submitted.
- XP: 10 per filled field, +20 when the match rate is 80% or more. Level N starts at 50*N*(N-1) XP. Day streak counts days with at least one filled form.
- Motion: ring and counters, staggered rows, XP float, level pop, an in-page ripple on filled fields and an "Applied" layer (drawn check, XP chip, auto-dismiss, Esc or click to close). All of it is off under `prefers-reduced-motion`.

## Develop
```bash
python3 scripts/mock-ctl.py ../ctl/workspace-service/database/data/career/career.json   # fake ctl on :8791
python3 -m http.server 8770                                                            # then open /dev/harness.html
```
The harness runs the real popup next to a fixture form with a `chrome.*` shim. Inter is optional: put `inter.woff2` in `fonts/`, otherwise it falls back to system-ui.

## Standards (ctl docs/11)
No gradients, no emoji, no decorative icons; the logo is the text wordmark `quiver.`.
