// أول تثبيت: افتح الإعدادات عشان توصّل ctl.
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') chrome.runtime.openOptionsPage()
})
