import { loadRules, getStats, summarize, award, levelOf, xpForLevel, rankOf } from './lib.js'

const $ = (id) => document.getElementById(id)
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
const sleep = (ms) => new Promise((r) => (reduced ? r() : setTimeout(r, ms)))
const CIRC = 326.7

let rules = []
let busy = false

/** عدّاد بيطلع من الرقم القديم للجديد. */
function count(el, to, suffix = '') {
  const from = parseInt(el.textContent) || 0
  if (reduced || from === to) return void (el.textContent = to + suffix)
  const t0 = performance.now()
  const dur = 700
  const tick = (t) => {
    const p = Math.min(1, (t - t0) / dur)
    el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3))) + suffix
    if (p < 1) requestAnimationFrame(tick)
  }
  requestAnimationFrame(tick)
}

function paintStats(s, { animate = true } = {}) {
  const lvl = levelOf(s.xp)
  const base = xpForLevel(lvl)
  const next = xpForLevel(lvl + 1)
  const lv = $('level')
  if (lv.textContent !== String(lvl)) {
    lv.textContent = lvl
    if (animate) { lv.classList.remove('pop'); void lv.offsetWidth; lv.classList.add('pop') }
  }
  $('rank').textContent = rankOf(lvl)
  $('xpbar').style.width = `${Math.round(((s.xp - base) / (next - base)) * 100)}%`
  $('xp').textContent = `${s.xp} XP`
  $('xpnext').textContent = `${next - s.xp} XP to level ${lvl + 1}`
  count($('s-forms'), s.forms)
  count($('s-fields'), s.fields)
  count($('s-streak'), s.streak)
  count($('s-best'), s.best, '%')
}

function paintSource(r) {
  const st = $('src-status')
  st.className = `state-${r.source}`
  st.textContent = r.source === 'ctl' ? 'Connected to ctl' : r.source === 'cache' ? `Using the last copy${r.error ? ` (${r.error})` : ''}` : r.error || 'Not connected'
  $('src-rules').textContent = String(r.rules.length)
  $('src-updated').textContent = r.updatedAt ? new Date(r.updatedAt).toLocaleString() : r.fetchedAt ? new Date(r.fetchedAt).toLocaleString() : '-'
}

function setHint(text, err = false) {
  const h = $('hint')
  h.textContent = text
  h.classList.toggle('err', err)
}

async function stepThrough(upTo) {
  const items = [...$('steps').children]
  items.forEach((li) => li.classList.remove('on'))
  for (const li of items.slice(0, upTo)) {
    li.classList.add('on')
    await sleep(170)
  }
}

function paintRows(rows) {
  const ul = $('rows')
  ul.replaceChildren()
  const order = { miss: 0, file: 0, kept: 1, ok: 2 }
  ;[...rows].sort((a, b) => order[a.status] - order[b.status]).forEach((r, i) => {
    const li = document.createElement('li')
    li.className = `row ${r.status}`
    li.style.setProperty('--i', Math.min(i, 12))
    const badge = document.createElement('div')
    badge.className = 'badge'
    badge.textContent = r.status === 'ok' ? 'OK' : r.status === 'kept' ? '=' : '!'
    const txt = document.createElement('div')
    txt.className = 'txt'
    const lbl = document.createElement('div')
    lbl.className = 'lbl'
    lbl.textContent = r.label
    const val = document.createElement('div')
    val.className = 'val'
    val.textContent = r.status === 'ok' ? r.value : r.status === 'kept' ? `${r.note}: ${r.value}` : r.note
    val.title = val.textContent
    txt.append(lbl, val)
    li.append(badge, txt)
    if (r.value) {
      const b = document.createElement('button')
      b.type = 'button'
      b.className = 'btn copy'
      b.textContent = 'Copy'
      b.onclick = async () => {
        await navigator.clipboard.writeText(r.value)
        b.textContent = 'Copied'
        b.classList.add('done')
        setTimeout(() => { b.textContent = 'Copy'; b.classList.remove('done') }, 1200)
      }
      li.append(b)
    }
    ul.append(li)
  })
}

function paintSummary(sum, scanOnly) {
  const arc = $('arc')
  arc.style.strokeDashoffset = String(CIRC * (1 - sum.rate / 100))
  count($('rate'), sum.rate, '%')
  count($('n-fields'), sum.fields)
  count($('n-matched'), sum.matched)
  count($('n-filled'), scanOnly ? 0 : sum.filled)
  const chain = $('chain')
  chain.hidden = sum.chain < 2
  chain.textContent = `chain x${sum.chain}`
  const r = $('result')
  r.classList.remove('pulse'); void r.offsetWidth; r.classList.add('pulse')
}

async function inPage(mode) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab || !/^https?:/i.test(tab.url || '')) throw new Error('Open a job application page first. Quiver cannot run on this tab.')
  await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ['engine.js'] })
  const out = await chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: (m, r) => window.__quiver.run(m, r),
    args: [mode, rules],
  })
  return out.flatMap((o) => o.result || [])
}

/** الطبقة دي بتظهر في الصفحة الرئيسية بس (مش في الـ iframes). */
async function showDone(info) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: (i) => window.__quiver.celebrate(i), args: [info] })
  } catch {}
}

async function go(mode) {
  if (busy) return
  busy = true
  $('fill').disabled = $('scan').disabled = true
  try {
    if (!rules.length) throw new Error('No rules yet. Open Settings and connect ctl, then Refresh rules.')
    setHint(mode === 'fill' ? 'Filling...' : 'Scanning...')
    const pending = stepThrough(mode === 'fill' ? 3 : 2)
    const rows = await inPage(mode)
    await pending
    if (!rows.length) {
      $('steps').querySelectorAll('li').forEach((li) => li.classList.remove('on'))
      setHint('No form fields found on this page.', true)
      return
    }
    const sum = summarize(rows)
    paintSummary(sum, mode === 'scan')
    paintRows(rows)
    if (mode === 'fill') {
      const left = sum.fields - sum.matched
      setHint(`${sum.filled} filled, ${left} left for you. Review the form before you submit.`)
      const { gained, stats, leveledUp } = await award(sum)
      if (gained) {
        const g = $('gain')
        g.textContent = `+${gained} XP`
        g.classList.remove('go'); void g.offsetWidth; g.classList.add('go')
      }
      paintStats(stats, { animate: leveledUp })
      if (sum.filled > 0) showDone({ filled: sum.filled, left, gained, level: leveledUp ? levelOf(stats.xp) : 0 })
    } else {
      setHint(`${sum.matched} of ${sum.fields} fields matched. Nothing was changed on the page.`)
    }
  } catch (e) {
    setHint(e.message || String(e), true)
  } finally {
    busy = false
    $('fill').disabled = $('scan').disabled = false
  }
}

async function refresh() {
  const r = await loadRules()
  rules = r.rules
  paintSource(r)
  if (r.source === 'none') setHint(r.error || 'Not connected to ctl.', true)
  else if (r.source === 'cache') setHint(`ctl is unreachable, using the last copy (${r.rules.length} rules).`)
  return r
}

$('fill').onclick = () => go('fill')
$('scan').onclick = () => go('scan')
$('settings').onclick = () => chrome.runtime.openOptionsPage()
$('refresh').onclick = async () => {
  setHint('Refreshing rules...')
  const r = await refresh()
  if (r.source === 'ctl') setHint(`Rules refreshed: ${r.rules.length} from ctl.`)
}

paintStats(await getStats(), { animate: false })
await refresh()
