/*
 * quiver. engine: بيتحقن في الصفحة (وفي الـ iframes). بيقرا الحقول، بيطابقها بقواعد ctl، وبيملاها.
 * مفيش أي اتصال بالشبكة هنا: القواعد بتتبعت له من الـ popup.
 */
(() => {
  if (window.__quiver) return

  const SKIP_TYPES = new Set(['hidden', 'password', 'submit', 'button', 'reset', 'image', 'checkbox', 'radio', 'range', 'color'])
  const reduced = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches

  const norm = (s) =>
    String(s || '')
      .toLowerCase()
      .replace(/[*:()[\]{}?!.,/\\_\-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()

  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const hasWord = (label, word) => {
    const w = norm(word)
    return !!w && new RegExp(`(^| )${esc(w)}( |$)`).test(label)
  }

  const visible = (el) => {
    const r = el.getBoundingClientRect()
    if (r.width === 0 && r.height === 0) return false
    const cs = getComputedStyle(el)
    return cs.visibility !== 'hidden' && cs.display !== 'none'
  }

  /** نص الـ label بأكتر من طريقة، بالترتيب من الأدق للأضعف. */
  function labelOf(el) {
    const doc = el.ownerDocument
    const out = []
    if (el.id) {
      const l = doc.querySelector(`label[for="${CSS.escape(el.id)}"]`)
      if (l) out.push(l.textContent)
    }
    const by = el.getAttribute('aria-labelledby')
    if (by) out.push(by.split(/\s+/).map((id) => doc.getElementById(id)?.textContent || '').join(' '))
    out.push(el.getAttribute('aria-label'))
    const wrap = el.closest('label')
    if (wrap) {
      const clone = wrap.cloneNode(true)
      clone.querySelectorAll('input,select,textarea,button').forEach((n) => n.remove())
      out.push(clone.textContent)
    }
    const group = el.closest('[class*="field" i],[class*="form-group" i],[class*="question" i],.form-row,fieldset')
    if (group && !out.some((x) => norm(x))) {
      const l = group.querySelector('label,legend,[class*="label" i]')
      if (l && !l.contains(el)) out.push(l.textContent)
    }
    out.push(el.getAttribute('placeholder'), el.getAttribute('name'), el.id, el.getAttribute('autocomplete'))
    return out.map(norm).filter(Boolean)
  }

  const display = (el, labels) => {
    const first = (el.ownerDocument.querySelector(`label[for="${CSS.escape(el.id || '_')}"]`) || el.closest('label'))?.textContent
    const raw = (first || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.name || el.id || 'Field').trim()
    return raw.replace(/\s+/g, ' ').replace(/\s*\*$/, '').slice(0, 60) || labels[0] || 'Field'
  }

  /** أحسن قاعدة: أطول keyword متطابقة بكلمات كاملة، ولو اتساوت الأقدم. */
  function match(labels, rules, isLong) {
    let best = null
    rules.forEach((rule, i) => {
      if (rule.long && !isLong) return
      for (const label of labels.slice(0, 4)) {
        if ((rule.exclude || []).some((x) => hasWord(label, x))) continue
        for (const k of rule.keywords || []) {
          if (!hasWord(label, k)) continue
          const score = norm(k).length
          if (!best || score > best.score) best = { rule, score, i }
        }
      }
    })
    return best && best.rule
  }

  function setValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
    el.focus({ preventScroll: true })
    setter ? setter.call(el, value) : (el.value = value)
    el.dispatchEvent(new Event('input', { bubbles: true }))
    el.dispatchEvent(new Event('change', { bubbles: true }))
    el.dispatchEvent(new Event('blur', { bubbles: true }))
  }

  function pickOption(select, value) {
    const v = norm(value)
    const opts = [...select.options].filter((o) => o.value !== '' || norm(o.textContent))
    const exact = opts.find((o) => norm(o.textContent) === v || norm(o.value) === v)
    if (exact) return exact
    return opts.find((o) => {
      const t = norm(o.textContent)
      return t.length >= 3 && (t.includes(v) || v.includes(t))
    })
  }

  const typeFits = (el, value) => {
    const t = (el.getAttribute('type') || 'text').toLowerCase()
    if (t === 'number') return /^-?\d+(\.\d+)?$/.test(String(value).trim())
    if (t === 'email') return /^\S+@\S+\.\S+$/.test(value)
    if (t === 'url') return /^https?:\/\//i.test(value)
    return true
  }

  function collect(root) {
    const found = []
    const walk = (node) => {
      node.querySelectorAll('input,select,textarea').forEach((el) => found.push(el))
      node.querySelectorAll('*').forEach((el) => el.shadowRoot && walk(el.shadowRoot))
    }
    walk(root)
    return found
  }

  /** mode: 'fill' | 'scan'. بيرجّع صفوف النتيجة بترتيب ظهورها في الصفحة. */
  function run(mode, rules) {
    const rows = []
    for (const el of collect(document)) {
      const type = (el.getAttribute('type') || (el.tagName === 'SELECT' ? 'select' : 'text')).toLowerCase()
      if (el.disabled || el.readOnly) continue
      if (type === 'file') {
        if (visible(el) || el.closest('label,[class*="upload" i],[class*="resume" i]')) {
          const labels = labelOf(el)
          rows.push({ status: 'file', label: display(el, labels), note: 'File upload: attach it yourself' })
        }
        continue
      }
      if (SKIP_TYPES.has(type) || !visible(el)) continue

      const labels = labelOf(el)
      const label = display(el, labels)
      const isLong = el.tagName === 'TEXTAREA' || el.isContentEditable
      const rule = match(labels, rules, isLong)
      if (!rule) {
        rows.push({ status: 'miss', label, note: 'No match: fill it yourself' })
        continue
      }
      const value = String(rule.value ?? '')
      if (!value) {
        rows.push({ status: 'miss', label, note: 'Matched, but ctl has no value for it yet' })
        continue
      }
      const had = el.tagName === 'SELECT' ? (el.selectedIndex > 0 && el.value !== '') : el.value.trim() !== ''
      if (had) {
        rows.push({ status: 'kept', label, value: el.tagName === 'SELECT' ? el.selectedOptions[0]?.textContent.trim() : el.value, note: 'Already had a value, kept it' })
        continue
      }
      if (el.tagName === 'SELECT') {
        const opt = pickOption(el, value)
        if (!opt) {
          rows.push({ status: 'miss', label, value, note: 'No option matches your value: pick it yourself' })
          continue
        }
        if (mode === 'fill') {
          setValue(el, opt.value)
          rows[rows.push({ status: 'ok', label, value: opt.textContent.trim() }) - 1].el = el
        } else rows.push({ status: 'ok', label, value: opt.textContent.trim(), dry: true })
        continue
      }
      if (!typeFits(el, value)) {
        rows.push({ status: 'miss', label, value, note: 'Value does not fit this field type: fill it yourself' })
        continue
      }
      if (mode === 'fill') {
        setValue(el, value)
        rows[rows.push({ status: 'ok', label, value }) - 1].el = el
      } else rows.push({ status: 'ok', label, value, dry: true })
    }

    const els = rows.map((r) => r.el).filter(Boolean)
    if (mode === 'fill' && els.length) {
      ripple(els)
    }
    return rows.map(({ el, ...r }) => r)
  }

  /** حركة هادية على الحقول المتملية: إطار indigo يظهر ويتلاشى بتتابع. */
  function ripple(els) {
    if (reduced()) return
    els.forEach((el, i) => {
      const prev = { shadow: el.style.boxShadow, tr: el.style.transition }
      setTimeout(() => {
        el.style.transition = 'box-shadow 260ms ease-out'
        el.style.boxShadow = '0 0 0 3px oklch(0.585 0.233 277.117 / 55%)'
        if (i === 0) el.scrollIntoView({ block: 'center', behavior: 'smooth' })
        setTimeout(() => {
          el.style.boxShadow = '0 0 0 0 oklch(0.585 0.233 277.117 / 0%)'
          setTimeout(() => {
            el.style.boxShadow = prev.shadow
            el.style.transition = prev.tr
          }, 420)
        }, 700)
      }, Math.min(i * 70, 1400))
    })
  }

  /** طبقة "Applied" فوق الصفحة: دايرة بتترسم، علامة صح بتتكتب، وبتختفي لوحدها. */
  function celebrate({ filled, left, gained, level }) {
    document.getElementById('__quiver_done')?.remove()
    const host = document.createElement('div')
    host.id = '__quiver_done'
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647'
    const root = host.attachShadow({ mode: 'open' })
    const dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
    const c = dark
      ? { card: 'oklch(0.242 0 0)', fg: 'oklch(0.985 0 0)', mute: 'oklch(0.708 0 0)', line: 'rgba(255,255,255,.12)', p: 'oklch(0.585 0.233 277.117)' }
      : { card: '#fff', fg: 'oklch(0.205 0 0)', mute: 'oklch(0.556 0 0)', line: 'oklch(0.922 0 0)', p: 'oklch(0.511 0.262 276.966)' }
    root.innerHTML = `
      <style>
        *{box-sizing:border-box}
        .scrim{position:absolute;inset:0;background:rgba(15,15,20,.42);opacity:0;transition:opacity 260ms ease;display:grid;place-items:center;cursor:pointer}
        .scrim.in{opacity:1}
        .card{width:300px;padding:26px 22px 18px;border-radius:18px;background:${c.card};color:${c.fg};border:1px solid ${c.line};
              box-shadow:0 24px 64px rgba(0,0,0,.35);text-align:center;font:500 14px/1.45 'Inter',system-ui,sans-serif;
              transform:translateY(18px) scale(.94);opacity:0;transition:transform 420ms cubic-bezier(.2,.9,.25,1.15),opacity 260ms}
        .in .card{transform:none;opacity:1}
        .brand{font-weight:600;letter-spacing:-.02em;direction:ltr;font-size:13px;color:${c.mute}}.brand i{font-style:normal;color:${c.p}}
        svg{width:84px;height:84px;margin:14px auto 10px;display:block;overflow:visible}
        .ring{fill:none;stroke:${c.p};stroke-width:5;stroke-linecap:round;stroke-dasharray:226;stroke-dashoffset:226;transform:rotate(-90deg);transform-origin:center}
        .disc{fill:${c.p};transform-origin:center;transform:scale(0)}
        .tick{fill:none;stroke:#fff;stroke-width:6;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:50;stroke-dashoffset:50}
        .in .ring{animation:draw 620ms cubic-bezier(.4,0,.2,1) 140ms forwards}
        .in .disc{animation:pop 380ms cubic-bezier(.2,.9,.25,1.3) 700ms forwards}
        .in .tick{animation:draw 340ms ease-out 860ms forwards}
        @keyframes draw{to{stroke-dashoffset:0}}
        @keyframes pop{to{transform:scale(1)}}
        h2{margin:0;font-size:22px;font-weight:700;letter-spacing:-.02em;opacity:0;transform:translateY(6px)}
        p{margin:4px 0 0;color:${c.mute};font-size:13px;opacity:0;transform:translateY(6px)}
        .chip{display:inline-block;margin-top:12px;padding:4px 12px;border-radius:999px;font-weight:700;font-size:13px;color:#fff;background:${c.p};opacity:0;transform:translateY(6px)}
        .in h2{animation:up 380ms ease-out 980ms forwards}.in p{animation:up 380ms ease-out 1060ms forwards}.in .chip{animation:up 380ms ease-out 1140ms forwards}
        @keyframes up{to{opacity:1;transform:none}}
        .bar{height:3px;margin:16px -22px -18px;background:${c.line};overflow:hidden;border-radius:0 0 18px 18px}
        .bar b{display:block;height:100%;width:100%;background:${c.p};transform-origin:left;transform:scaleX(1)}
        .in .bar b{animation:shrink 3200ms linear 1200ms forwards}
        @keyframes shrink{to{transform:scaleX(0)}}
        @media (prefers-reduced-motion:reduce){
          *{animation-duration:1ms!important;animation-delay:0s!important;transition-duration:1ms!important}
          .ring{stroke-dashoffset:0}.disc{transform:scale(1)}.tick{stroke-dashoffset:0}h2,p,.chip{opacity:1;transform:none}
        }
      </style>
      <div class="scrim" role="status" aria-live="polite">
        <div class="card">
          <div class="brand">quiver<i>.</i></div>
          <svg viewBox="0 0 84 84" aria-hidden="true">
            <circle class="disc" cx="42" cy="42" r="36"/>
            <circle class="ring" cx="42" cy="42" r="36"/>
            <path class="tick" d="M27 43 l11 11 l20 -23"/>
          </svg>
          <h2>Applied</h2>
          <p class="sub"></p>
          <span class="chip"></span>
          <div class="bar"><b></b></div>
        </div>
      </div>`
    root.querySelector('.sub').textContent = left > 0 ? `${filled} filled, ${left} left for you. Review before you submit.` : `${filled} filled. Review before you submit.`
    const chip = root.querySelector('.chip')
    if (gained) chip.textContent = `+${gained} XP${level ? `  ·  Level ${level}` : ''}`
    else chip.remove()
    document.documentElement.appendChild(host)
    const scrim = root.querySelector('.scrim')
    requestAnimationFrame(() => scrim.classList.add('in'))
    let gone = false
    const close = () => {
      if (gone) return
      gone = true
      scrim.classList.remove('in')
      setTimeout(() => host.remove(), 320)
    }
    scrim.addEventListener('click', close)
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc) } })
    setTimeout(close, 4600)
  }

  window.__quiver = { run, celebrate, norm, match }
})()
