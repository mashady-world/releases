import { getConfig, saveConfig, loadRules } from './lib.js'

const $ = (id) => document.getElementById(id)
const msg = (t, cls = '') => { $('msg').textContent = t; $('msg').className = cls }

const cfg = await getConfig()
$('base').value = cfg.baseUrl
$('token').value = cfg.token

$('form').onsubmit = async (e) => {
  e.preventDefault()
  const baseUrl = $('base').value.trim().replace(/\/+$/, '')
  try {
    const origin = new URL(baseUrl).origin + '/*'
    // الإذن لعنوان ctl بس، مش لكل المواقع.
    const granted = await chrome.permissions.request({ origins: [origin] })
    if (!granted) return msg('Permission to reach that address was declined.', 'err')
  } catch {
    return msg('That is not a valid URL.', 'err')
  }
  await saveConfig({ baseUrl, token: $('token').value })
  msg('Testing...')
  const r = await loadRules()
  if (r.source === 'ctl') msg(`Connected. ${r.rules.length} rules loaded.`, 'ok')
  else msg(r.error || 'Could not reach ctl.', 'err')
}
