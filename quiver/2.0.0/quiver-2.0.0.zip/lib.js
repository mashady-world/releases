/* quiver. shared logic: ctl connection, rules cache, XP and levels. */

const KEY_CONFIG = 'quiver.config'
const KEY_CACHE = 'quiver.cache'
const KEY_STATS = 'quiver.stats'

const store = {
  get: async (k) => (await chrome.storage.local.get(k))[k],
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
}

export const getConfig = async () => (await store.get(KEY_CONFIG)) || { baseUrl: '', token: '' }
export const saveConfig = (c) => store.set(KEY_CONFIG, { baseUrl: c.baseUrl.trim().replace(/\/+$/, ''), token: c.token.trim() })

const timeout = (ms) => AbortSignal.timeout(ms)

/** القواعد من ctl، ولو وقع بنكمّل من آخر نسخة محفوظة. */
export async function loadRules() {
  const cfg = await getConfig()
  const cache = await store.get(KEY_CACHE)
  if (!cfg.baseUrl || !cfg.token) {
    return cache
      ? { rules: cache.rules, source: 'cache', updatedAt: cache.updatedAt, fetchedAt: cache.fetchedAt, error: 'ctl is not set up' }
      : { rules: [], source: 'none', error: 'ctl is not set up' }
  }
  try {
    const res = await fetch(`${cfg.baseUrl}/api/consumer/autofill`, {
      headers: { Authorization: `Bearer ${cfg.token}`, Accept: 'application/json' },
      signal: timeout(6000),
    })
    if (res.status === 401 || res.status === 403) throw new Error('Token rejected. Make a new one with the autofill scope.')
    if (!res.ok) throw new Error(`ctl answered ${res.status}`)
    const data = await res.json()
    const rules = Array.isArray(data.entries) ? data.entries : []
    const fresh = { rules, updatedAt: data.updatedAt || null, fetchedAt: Date.now() }
    await store.set(KEY_CACHE, fresh)
    return { ...fresh, source: 'ctl' }
  } catch (e) {
    const error = e.name === 'TimeoutError' ? 'ctl did not answer in time' : e.message || 'ctl is unreachable'
    return cache
      ? { rules: cache.rules, source: 'cache', updatedAt: cache.updatedAt, fetchedAt: cache.fetchedAt, error }
      : { rules: [], source: 'none', error }
  }
}

/* ── XP, levels, ranks ───────────────────────────────────────── */
export const xpForLevel = (l) => 50 * l * (l - 1) // L2 = 100, L3 = 300, L4 = 600
export const levelOf = (xp) => {
  let l = 1
  while (xp >= xpForLevel(l + 1)) l++
  return l
}
const RANKS = [
  [1, 'Rookie'],
  [3, 'Scout'],
  [5, 'Ranger'],
  [8, 'Archer'],
  [12, 'Sharpshooter'],
  [17, 'Legend'],
]
export const rankOf = (level) => RANKS.filter(([min]) => level >= min).pop()[1]

const day = (d = new Date()) => d.toISOString().slice(0, 10)
const EMPTY = { xp: 0, forms: 0, fields: 0, streak: 0, lastDay: null, best: 0 }

export const getStats = async () => ({ ...EMPTY, ...(await store.get(KEY_STATS)) })

export function summarize(rows) {
  const fields = rows.length
  const matched = rows.filter((r) => r.status === 'ok' || r.status === 'kept').length
  const filled = rows.filter((r) => r.status === 'ok' && !r.dry).length
  let chain = 0
  let run = 0
  for (const r of rows) {
    run = r.status === 'ok' || r.status === 'kept' ? run + 1 : 0
    chain = Math.max(chain, run)
  }
  return { fields, matched, filled, chain, rate: fields ? Math.round((matched / fields) * 100) : 0 }
}

/** 10 XP لكل حقل اتملا، و20 زيادة لو المطابقة 80% أو أكتر. */
export async function award(sum) {
  const before = await getStats()
  const gained = sum.filled * 10 + (sum.filled > 0 && sum.rate >= 80 ? 20 : 0)
  const today = day()
  const yesterday = day(new Date(Date.now() - 864e5))
  const streak = before.lastDay === today ? before.streak : before.lastDay === yesterday ? before.streak + 1 : 1
  const next = {
    xp: before.xp + gained,
    forms: before.forms + (sum.filled > 0 ? 1 : 0),
    fields: before.fields + sum.filled,
    streak: sum.filled > 0 ? streak : before.streak,
    lastDay: sum.filled > 0 ? today : before.lastDay,
    best: Math.max(before.best, sum.filled > 0 ? sum.rate : 0),
  }
  await store.set(KEY_STATS, next)
  return { gained, stats: next, leveledUp: levelOf(next.xp) > levelOf(before.xp) }
}
